# 🚀 24/7 Hosting Guide — 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 (Bot + Web Dashboard)

This project contains **both the 24/7 Discord Music Bot and the interactive Lossless Audio Web Dashboard** in a single unified architecture. When you deploy it, both the **Discord Bot** and the **Live Website** run simultaneously!

---

## ⚡ Option 1: Railway (Best & Easiest — Recommended)
Railway automatically detects the `Dockerfile`, installs FFmpeg for high-quality audio, runs the bot 24/7, and generates a free public **HTTPS website domain** for your dashboard.

### Step-by-Step:
1. **Create an account** on [Railway.app](https://railway.app/).
2. Click **"+ New Project"** → **"Deploy from GitHub repo"** (or use the Railway CLI).
   - If deploying from GitHub: Push the unzipped project folder to a GitHub repository (set to Private or Public).
   - Alternatively, you can use the Railway CLI from your computer:
     ```bash
     npm i -g @railway/cli
     railway login
     railway init
     railway up
     ```
3. In your Railway project **Variables** tab, add:
   - `DISCORD_TOKEN`: `your_discord_bot_token`
4. In your Railway service **Settings** tab:
   - Under **Networking** / **Public Networking**, click **"Generate Domain"**.
   - Railway will provide a public URL like: `https://lana-del-rey-production.up.railway.app`
5. Add one more environment variable:
   - `DASHBOARD_URL`: `https://your-generated-domain.up.railway.app`
6. Click **Deploy**.
   - Your **Discord Bot** is now online 24/7!
   - Your **Website** is live worldwide at your generated HTTPS URL!

---

## 🌐 Option 2: Render.com (Simple Cloud Hosting)
Render allows you to host web services and background workers with free SSL certificates.

### Step-by-Step:
1. Create an account on [Render.com](https://render.com/).
2. Push your project to a GitHub repository.
3. Click **"New +"** → **"Web Service"**.
4. Connect your GitHub repository.
5. Choose:
   - **Environment**: `Docker` (Render will automatically detect the provided `Dockerfile` and build it with FFmpeg).
   - **Instance Type**: `Free` or `Starter`.
6. Under **Environment Variables**, add:
   - `DISCORD_TOKEN`: `your_discord_bot_token`
   - `PORT`: `5050` (or leave default, Render sets this automatically)
7. Click **"Create Web Service"**.
   - Once deployed, Render gives you a public URL (`https://your-bot.onrender.com`).
   - Copy that URL and set `DASHBOARD_URL = https://your-bot.onrender.com`.

---

## ☁️ Option 3: Koyeb (Docker Native)
1. Sign up on [Koyeb.com](https://www.koyeb.com/).
2. Click **"Create App"** → choose **GitHub**.
3. Select your repository.
4. Set builder to **Dockerfile**.
5. Add secret:
   - `DISCORD_TOKEN` = `your_discord_bot_token`
6. Set exposed port to `5050`.
7. Click **Deploy**. Koyeb will give you a live HTTPS domain for your website!

---

## 🖥️ Option 4: Linux VPS (DigitalOcean / Hetzner / AWS / Linode)
If you have a Linux server (Ubuntu/Debian), you can run it 24/7 with zero limits:

### Setup Commands:
```bash
# 1. Update and install system requirements
sudo apt update && sudo apt install -y python3 python3-pip python3-venv ffmpeg git nodejs npm

# 2. Install PM2 process manager
sudo npm install -g pm2

# 3. Clone or upload your files
cd /var/www/lana_del_rey_bot

# 4. Set up Python virtual environment
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 5. Create your .env file
nano .env
# Put: DISCORD_TOKEN=your_token_here

# 6. Start 24/7 with PM2
pm2 start bot.py --name "lana-bot" --interpreter .venv/bin/python3
pm2 save
pm2 startup
```

---

## 🔑 Required Discord Developer Portal Settings
Before hosting on any platform, make sure these are enabled in the [Discord Developer Portal](https://discord.com/developers/applications):
1. Go to your bot application → **Bot** tab.
2. Scroll to **Privileged Gateway Intents**:
   - ✅ **Presence Intent**
   - ✅ **Server Members Intent**
   - ✅ **Message Content Intent**
3. Click **Save Changes**.
