# 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 — Discord Music Bot & Live Dashboard

High quality Discord music bot featuring crystal-clear 24-bit audio, 24/7 voice persistence, interactive playback controls, video/MP3 importing, and a real-time dark luxury web dashboard!

---

## ✨ Features

- 🎵 **Multi-Source Playback:** Stream from YouTube, search queries, direct URLs, or local media.
- 📂 **Import Video & MP3:** Drag-and-drop or upload MP3 audio (`.mp3`, `.wav`, `.m4a`, `.flac`) and Video files (`.mp4`, `.webm`, `.mov`, `.mkv`) via `/import` or the Web Dashboard.
- 🎛️ **Live Web Dashboard (`http://localhost:5050`):**
  - Switch between all connected servers.
  - One-click voice join / disconnect per server.
  - Real-time queue, seek bar, volume control, and 720P video stream.
  - Cinematic Lana Del Rey background with 3D red & white falling rose petals!
- 🛡️ **24/7 Voice Shield:** Automatically rejoins voice after restarts, disconnects, or drag events.
- 🔒 **Owner Security Shield:** Bot avatar, banner, and nickname commands are strictly locked to the bot owner.
- 🔔 **Instant Server Join DM Alerts:** Sends rich DM notification to bot owner whenever invited to a new server.

---

## 🚀 Quick Setup & Hosting

### Option 1: Standard Hosting (Linux VPS, macOS, Windows)

1. **Install Prerequisites:**
   - Python 3.10+
   - [FFmpeg](https://ffmpeg.org/download.html) installed and in your system `PATH`:
     ```bash
     # Ubuntu / Debian
     sudo apt update && sudo apt install -y ffmpeg

     # macOS (Homebrew)
     brew install ffmpeg
     ```

2. **Configure Environment:**
   Copy `.env.example` to `.env` (or use your existing `.env`):
   ```ini
   DISCORD_BOT_TOKEN=your_token_here
   DASHBOARD_PORT=5050
   ```

3. **Install Dependencies:**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```

4. **Run the Bot:**
   ```bash
   python bot.py
   ```
   Or run persistently with **PM2**:
   ```bash
   npm install -g pm2
   pm2 start "python bot.py" --name "lana-bot"
   pm2 save && pm2 startup
   ```

---

### Option 2: Docker Hosting (1-Click Run)

```bash
docker compose up -d --build
```

---

### Option 3: Cloud Hosting (Railway / Render / Fly.io)

1. Connect your GitHub repository to Railway or Render.
2. Set the Environment Variable:
   - `DISCORD_BOT_TOKEN`: Your Discord bot token.
3. The included `Dockerfile` and `Procfile` will automatically install FFmpeg and run the bot!

---

## 📜 Key Commands

| Command | Description |
|---|---|
| `/play <query>` | Play a song title or YouTube link |
| `/import <file>` | Import and play an MP3 audio or Video song file |
| `/pause` / `/resume` | Pause or resume audio |
| `/skip` / `/stop` | Skip track or stop playback |
| `/queue` / `/clear` | View or clear upcoming queue |
| `/247` | Toggle 24/7 mode in current voice channel |
| `/controller` | Open interactive button playback controller |
| `/stream` | Stream 720P video in Discord and launch Watch Together |
| `/setavatar <file>` | Set bot profile avatar *(Bot Owner Only)* |
| `/setbanner <file>` | Set bot profile banner *(Bot Owner Only)* |
| `/setnick <name>` | Change bot nickname *(Bot Owner Only)* |
| `/owner` | View bot owner statistics and admin panel |
| `/help` | Complete bot command list |
