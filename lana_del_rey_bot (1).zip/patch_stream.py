import re
from pathlib import Path

bot_file = Path("/Users/athi/Downloads/visual code/bot.py")
content = bot_file.read_text(encoding="utf-8")

# 1. Update Track dataclass to have video_id
track_target = '''@dataclass(frozen=True)
class Track:
    title: str
    source: str
    is_url: bool = False
    duration: str = "Unknown"
    thumbnail: str | None = None
    webpage_url: str | None = None
    uploader: str = "YouTube"
    requester: str = "Unknown"'''

track_replacement = '''@dataclass(frozen=True)
class Track:
    title: str
    source: str
    is_url: bool = False
    duration: str = "Unknown"
    thumbnail: str | None = None
    webpage_url: str | None = None
    uploader: str = "YouTube"
    requester: str = "Unknown"
    video_id: str | None = None'''

if track_target in content:
    content = content.replace(track_target, track_replacement)
    print("✓ Track dataclass updated with video_id")
else:
    print("! Track target not found")

# 2. Update extract_youtube_track to extract video_id and pass it
old_extract_return = '''    return Track(
        title=title,
        source=info["url"],
        is_url=True,
        duration=duration_str,
        thumbnail=thumbnail,
        webpage_url=webpage_url,
        uploader=uploader,
        requester=requester,
    )'''

new_extract_return = '''    video_id = info.get("id")
    if not video_id and webpage_url:
        vm = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11})', webpage_url)
        if vm:
            video_id = vm.group(1)

    return Track(
        title=title,
        source=info["url"],
        is_url=True,
        duration=duration_str,
        thumbnail=thumbnail,
        webpage_url=webpage_url,
        uploader=uploader,
        requester=requester,
        video_id=video_id,
    )'''

if old_extract_return in content:
    content = content.replace(old_extract_return, new_extract_return)
    print("✓ extract_youtube_track updated with video_id extraction")
else:
    print("! old_extract_return not found")

# 3. Update ExtrasControls to match Image 3 exactly
extras_pattern = r'class ExtrasControls\(discord\.ui\.View\):.*?(?=def extract_youtube_track)'

new_extras = '''class ExtrasControls(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=None)
        self.guild_id = guild_id
        if guild_id in bot.autoplay:
            self.autoplay_btn.style = discord.ButtonStyle.success
            self.autoplay_btn.label = "Autoplay ON"

    # --- ROW 0: Queue, Shuffle, Lyrics (Matches Screenshot) ---
    @discord.ui.button(label="Queue", emoji="🔄", style=discord.ButtonStyle.secondary, row=0)
    async def queue_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        queue = list(bot.queues[self.guild_id])
        if not queue:
            msg = "The queue is empty."
        else:
            msg = "Upcoming tracks:\\n" + "\\n".join(
                f"{idx}. `{t.title}` (`{t.duration}`)" for idx, t in enumerate(queue[:10], start=1)
            )
        await interaction.response.send_message(msg, ephemeral=True)

    @discord.ui.button(label="Shuffle", emoji="🔀", style=discord.ButtonStyle.secondary, row=0)
    async def shuffle_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        import random
        queue = bot.queues[self.guild_id]
        if len(queue) < 2:
            await interaction.response.send_message("❌ Need at least 2 tracks in queue to shuffle.", ephemeral=True)
            return
        tracks_list = list(queue)
        random.shuffle(tracks_list)
        bot.queues[self.guild_id] = deque(tracks_list)
        await interaction.response.send_message(f"🔀 Shuffled **{len(tracks_list)}** tracks!", ephemeral=True)

    @discord.ui.button(label="Lyrics", emoji="📜", style=discord.ButtonStyle.secondary, row=0)
    async def lyrics_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        embed = discord.Embed(
            title=f"📜 Song Details • {track.title[:45]}",
            description=f"**Title**: [{track.title}]({track.webpage_url or 'https://youtube.com'})\\n**Artist/Channel**: `{track.uploader}`\\n**Duration**: `{track.duration}`\\n**Requested by**: {track.requester}\\n\\n*Live streaming synced with web dashboard!*",
            color=discord.Color.from_rgb(245, 197, 24)
        )
        if track.thumbnail:
            embed.set_thumbnail(url=track.thumbnail)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # --- ROW 1: Save, Share (Matches Screenshot) ---
    @discord.ui.button(label="Save", emoji="💾", style=discord.ButtonStyle.secondary, row=1)
    async def save_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        embed = discord.Embed(
            title="📥 Saved Track",
            description=f"**[{track.title}]({track.webpage_url or 'https://youtube.com'})**",
            color=discord.Color.from_rgb(245, 197, 24)
        )
        if track.thumbnail:
            embed.set_thumbnail(url=track.thumbnail)
        embed.add_field(name="Duration", value=f"`{track.duration}`", inline=True)
        embed.add_field(name="Channel", value=f"`{track.uploader}`", inline=True)
        embed.set_footer(text=f"Saved from {interaction.guild.name} • YADZ Music")
        try:
            await interaction.user.send(embed=embed)
            await interaction.response.send_message("📬 Sent song details to your DMs!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Please enable DMs from server members.", ephemeral=True)

    @discord.ui.button(label="Share", emoji="📤", style=discord.ButtonStyle.secondary, row=1)
    async def share_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"🎶 **Now Playing**: [{track.title}]({track.webpage_url or 'https://youtube.com'}) (Shared by {interaction.user.mention})"
        )

    # --- ROW 2: Autoplay & Stream Video (Matches Screenshot Image 3) ---
    @discord.ui.button(label="Autoplay", emoji="📻", style=discord.ButtonStyle.secondary, row=2)
    async def autoplay_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.guild_id in bot.autoplay:
            bot.autoplay.remove(self.guild_id)
            button.style = discord.ButtonStyle.secondary
            button.label = "Autoplay"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("📻 **Autoplay disabled**.", ephemeral=True)
        else:
            bot.autoplay.add(self.guild_id)
            button.style = discord.ButtonStyle.success
            button.label = "Autoplay ON"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("📻 **Autoplay enabled**! Similar songs will play automatically when the queue finishes.", ephemeral=True)

    @discord.ui.button(label="Stream", emoji="📺", style=discord.ButtonStyle.primary, row=2)
    async def stream_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await stream_command(interaction, query=None)

'''

m_ext = re.search(extras_pattern, content, re.DOTALL)
if m_ext:
    content = content[:m_ext.start()] + new_extras + content[m_ext.end():]
    print("✓ ExtrasControls updated to match Image 3 exactly")
else:
    print("! ExtrasControls pattern not found")

# 4. Add StreamView and /stream slash command
stream_cmd_block = '''
class StreamView(discord.ui.View):
    def __init__(self, youtube_url: str = None, watch_together_url: str = None):
        super().__init__(timeout=None)
        if youtube_url:
            self.add_item(discord.ui.Button(label="Watch on YouTube", emoji="📺", url=youtube_url, style=discord.ButtonStyle.link))
        if watch_together_url:
            self.add_item(discord.ui.Button(label="Watch Together (Voice)", emoji="🚀", url=watch_together_url, style=discord.ButtonStyle.link))
        self.add_item(discord.ui.Button(label="Web Dashboard 720P", emoji="🌐", url="http://localhost:5050", style=discord.ButtonStyle.link))


@bot.tree.command(name="stream", description="Stream YouTube video song in 720P 30FPS & launch Watch Together")
@app_commands.guild_only()
@app_commands.describe(query="Song title, video name, or YouTube URL to stream (e.g. 'hindi item songs')")
async def stream_command(interaction: discord.Interaction, query: str = None) -> None:
    if not interaction.response.is_done():
        await interaction.response.defer()

    guild_id = interaction.guild_id
    requester_name = interaction.user.display_name

    track = None
    if query:
        try:
            track = await asyncio.to_thread(extract_youtube_track, query, requester_name)
        except Exception as e:
            await interaction.followup.send(f"❌ Could not load video stream: `{e}`")
            return
    else:
        track = bot.current_track.get(guild_id)
        if not track:
            track = await asyncio.to_thread(extract_youtube_track, "hindi item songs", requester_name)

    watch_together_url = None
    # Connect bot to voice if user is connected
    if interaction.user.voice and interaction.user.voice.channel:
        vc_channel = interaction.user.voice.channel
        if not interaction.guild.voice_client:
            try:
                await vc_channel.connect()
            except Exception:
                pass

        # Try to generate Discord Watch Together Activity invite
        try:
            invite = await vc_channel.create_invite(
                target_type=discord.InviteTarget.embedded_application,
                target_application_id=880218394199220334,
                max_age=86400,
                max_uses=0
            )
            watch_together_url = invite.url
        except Exception as e:
            print(f"Watch together notice: {e}")

        # Start playback if requested new track
        if query:
            bot.queues[guild_id].appendleft(track)
            vc = interaction.guild.voice_client
            if vc and (not vc.is_playing() and not vc.is_paused()):
                await play_next(guild_id)

    embed = discord.Embed(
        title="📺 720P 30FPS LIVE • YouTube Video Stream",
        description=(
            f"> **❯ Video Title** : [{track.title}]({track.webpage_url or 'https://youtube.com'})\\n"
            f"> **❯ Channel** : `{track.uploader}`\\n"
            f"> **❯ Duration** : `{track.duration}`\\n"
            f"> **❯ Stream Quality** : `720P 30FPS LIVE • Lossless Audio`\\n"
            f"> **❯ Requested by** : {interaction.user.mention}\\n\\n"
            "*Streaming audio in voice channel & live video stream on YouTube and Discord Watch Together!*"
        ),
        color=discord.Color.from_rgb(255, 0, 0)
    )
    if track.thumbnail:
        embed.set_image(url=track.thumbnail)
    embed.set_footer(text="YADZ Live Streaming Engine • 720P 30FPS HD")

    view = StreamView(youtube_url=track.webpage_url, watch_together_url=watch_together_url)
    await interaction.followup.send(embed=embed, view=view)
'''

if '@bot.tree.command(name="stream"' not in content:
    idx_ready = content.find('@bot.event\nasync def on_ready()')
    if idx_ready != -1:
        content = content[:idx_ready] + stream_cmd_block + "\n" + content[idx_ready:]
        print("✓ StreamView and /stream command added to bot.py")
    else:
        print("! on_ready marker not found for stream insertion")

# 5. Pass video_id in cur_data inside handle_api_live
old_cur_data = '''            cur_data = {
                "title": current.title,
                "uploader": current.uploader,
                "duration": current.duration,
                "duration_sec": dur_sec,
                "elapsed_sec": elapsed_sec,
                "thumbnail": current.thumbnail,
                "webpage_url": current.webpage_url,
                "requester": current.requester,
                "is_url": current.is_url
            }'''

new_cur_data = '''            vid_id = getattr(current, "video_id", None)
            if not vid_id and current.webpage_url:
                vm = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11})', current.webpage_url)
                if vm:
                    vid_id = vm.group(1)

            cur_data = {
                "title": current.title,
                "uploader": current.uploader,
                "duration": current.duration,
                "duration_sec": dur_sec,
                "elapsed_sec": elapsed_sec,
                "thumbnail": current.thumbnail,
                "webpage_url": current.webpage_url,
                "requester": current.requester,
                "is_url": current.is_url,
                "video_id": vid_id
            }'''

if old_cur_data in content:
    content = content.replace(old_cur_data, new_cur_data)
    print("✓ handle_api_live updated with video_id in cur_data")

bot_file.write_text(content, encoding="utf-8")
print("Finished patching bot.py!")
