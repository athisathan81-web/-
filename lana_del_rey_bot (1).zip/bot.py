import asyncio
import json
import math
import os
import subprocess
import random
import re
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
import aiohttp
from aiohttp import web
import yt_dlp


def safe_latency(val: float) -> int:
    try:
        if math.isfinite(val) and val >= 0:
            return max(1, round(val * 1000))
    except Exception:
        pass
    return 17


def get_media_duration_str(file_path: Path) -> tuple[str, int]:
    try:
        cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", str(file_path)
        ]
        out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, timeout=4).decode().strip()
        secs = int(float(out))
        m, s = divmod(secs, 60)
        h, m = divmod(m, 60)
        dur_str = f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
        return dur_str, secs
    except Exception:
        return "Imported File", 0


BASE_DIR = Path(__file__).resolve().parent
MUSIC_DIR = BASE_DIR / "music"
SUPPORTED_FORMATS = {".mp3", ".wav", ".ogg", ".flac", ".m4a"}
YOUTUBE_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be"}

load_dotenv(BASE_DIR / ".env")


@dataclass(frozen=True)
class Track:
    title: str
    source: str
    is_url: bool = False
    duration: str = "Unknown"
    thumbnail: str | None = None
    webpage_url: str | None = None
    uploader: str = "YouTube"
    requester: str = "Unknown"
    video_id: str | None = None


FILTER_PRESETS = {
    "bassboost": '-af "bass=g=12,dynaudnorm=f=200"',
    "8d": '-af "apulsator=hz=0.125"',
    "nightcore": '-af "asetrate=44100*1.25,aresample=44100,atempo=1.05"',
    "vaporwave": '-af "asetrate=44100*0.8,aresample=44100,atempo=1.0"',
    "karaoke": '-af "stereotools=mlev=0.01"',
    "clear": ""
}


def parse_duration_to_seconds(dur_str: str) -> int:
    try:
        parts = [int(p) for p in dur_str.strip().split(":")]
        if len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
        elif len(parts) == 2:
            return parts[0] * 60 + parts[1]
        elif len(parts) == 1:
            return parts[0]
    except Exception:
        pass
    return 0


def get_track_elapsed_sec(bot_instance, guild_id: int) -> int:
    start_t = bot_instance.track_start_time.get(guild_id, 0)
    if not start_t:
        return 0
    pause_t = bot_instance.pause_start_time.get(guild_id, 0)
    paused_acc = bot_instance.total_paused_duration.get(guild_id, 0.0)
    if pause_t > 0:
        elapsed = pause_t - start_t - paused_acc
    else:
        elapsed = time.time() - start_t - paused_acc
    return max(0, int(elapsed))


def json_cors(data: dict, status: int = 200) -> web.Response:
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
    }
    return web.json_response(data, status=status, headers=headers)


class MusicBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.members = True
        super().__init__(command_prefix=commands.when_mentioned, intents=intents)
        self.queues: dict[int, deque[Track]] = defaultdict(deque)
        self.channels: dict[int, discord.abc.Messageable] = {}
        self.history: dict[int, list[Track]] = defaultdict(list)
        self.current_track: dict[int, Track] = {}
        self.mode_247_file = BASE_DIR / "mode_247.json"
        self.mode_247_channels: dict[int, int] = {}
        self.mode_247: set[int] = set()
        self.load_247_config()
        self.autoplay: set[int] = set()
        self.favorites: dict[int, list[Track]] = defaultdict(list)
        self.filters: dict[int, str] = {}
        self.track_start_time: dict[int, float] = {}
        self.pause_start_time: dict[int, float] = {}
        self.total_paused_duration: dict[int, float] = defaultdict(float)
        self.volume: dict[int, float] = defaultdict(lambda: 1.0)
        self.boot_time: float = time.time()
        self.authorized_vc_moves: dict[int, float] = {}

    def load_247_config(self) -> None:
        try:
            if self.mode_247_file.exists():
                with open(self.mode_247_file, "r") as f:
                    content = f.read().strip()
                    if content:
                        data = json.loads(content)
                        self.mode_247_channels = {int(k): int(v) for k, v in data.items()}
                        self.mode_247 = set(self.mode_247_channels.keys())
                        print(f"Loaded {len(self.mode_247)} persistent 24/7 server configurations.")
        except Exception as e:
            print(f"Failed to load 24/7 config: {e}")

    def save_247_config(self) -> None:
        try:
            with open(self.mode_247_file, "w") as f:
                json.dump({str(k): v for k, v in self.mode_247_channels.items()}, f, indent=2)
        except Exception as e:
            print(f"Failed to save 24/7 config: {e}")

    def get_target_guild(self, guild_id: int | None = None) -> discord.Guild | None:
        if guild_id:
            try:
                gid_int = int(guild_id)
                g = self.get_guild(gid_int)
                if g:
                    return g
            except (ValueError, TypeError):
                pass

        # 1. Check if owner server (𝐙𝐄𝐗𝐈 愛 • 1459166857734127759) is actively playing
        owner_guild = self.get_guild(1459166857734127759)
        if owner_guild and owner_guild.voice_client and (owner_guild.voice_client.is_playing() or owner_guild.voice_client.is_paused()):
            return owner_guild

        # 2. Check if any other server is actively playing
        for g in self.guilds:
            vc = g.voice_client
            if vc and (vc.is_playing() or vc.is_paused()):
                return g

        # 3. Check if owner server is connected to voice
        if owner_guild and owner_guild.voice_client and owner_guild.voice_client.is_connected():
            return owner_guild

        # 4. Check if any other server is connected to voice
        for g in self.guilds:
            if g.voice_client and g.voice_client.is_connected():
                return g

        # 5. Default to owner server if bot is in it
        if owner_guild:
            return owner_guild

        if self.guilds:
            return self.guilds[0]
        return None

    async def setup_hook(self) -> None:
        await self.tree.sync()
        try:
            app = web.Application()
            app.router.add_get('/', self.handle_web_dashboard)
            app.router.add_get('/bot_avatar.png', self.handle_bot_avatar)
            app.router.add_get('/bg_lana.jpg', self.handle_bg_lana)
            app.router.add_get('/athi.jpg', self.handle_athi_img)
            app.router.add_get('/yadz.jpg', self.handle_yadz_img)
            swarm_dir = BASE_DIR / "dashboard" / "swarm"
            if swarm_dir.exists():
                app.router.add_static('/swarm', path=str(swarm_dir))
            app.router.add_get('/swarm-init.js', self.handle_swarm_init)
            app.router.add_get('/api/status', self.handle_api_status)
            app.router.add_get('/api/live', self.handle_api_live)
            app.router.add_post('/api/pause', self.handle_api_pause)
            app.router.add_post('/api/resume', self.handle_api_pause)
            app.router.add_post('/api/skip', self.handle_api_skip)
            app.router.add_post('/api/prev', self.handle_api_prev)
            app.router.add_post('/api/volume', self.handle_api_volume)
            app.router.add_post('/api/shuffle', self.handle_api_shuffle)
            app.router.add_post('/api/autoplay', self.handle_api_autoplay)
            app.router.add_post('/api/play', self.handle_api_play)
            app.router.add_post('/api/join', self.handle_api_join)
            app.router.add_post('/api/disconnect', self.handle_api_disconnect)
            app.router.add_post('/api/import', self.handle_api_import)
            app.router.add_route('OPTIONS', '/{tail:.*}', self.handle_api_options)

            runner = web.AppRunner(app)
            await runner.setup()
            web_port = int(os.getenv("PORT", 5050))
            site = web.TCPSite(runner, '0.0.0.0', web_port)
            await site.start()
            dash_url = os.getenv("DASHBOARD_URL", f"http://localhost:{web_port}")
            print(f"Web dashboard live at {dash_url}")
        except Exception as e:
            print(f"Web server info: {e}")

    async def handle_api_options(self, request: web.Request) -> web.Response:
        headers = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
        }
        return web.Response(status=200, headers=headers)

    async def handle_web_dashboard(self, request: web.Request) -> web.StreamResponse:
        dashboard_file = BASE_DIR / "dashboard" / "index.html"
        if dashboard_file.exists():
            return web.FileResponse(dashboard_file)
        return web.Response(text="𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 Music Bot is running!", content_type="text/html")

    async def handle_bot_avatar(self, request: web.Request) -> web.StreamResponse:
        avatar_file = BASE_DIR / "dashboard" / "bot_avatar.png"
        if avatar_file.exists():
            return web.FileResponse(avatar_file)
        if self.user and self.user.display_avatar:
            raise web.HTTPFound(str(self.user.display_avatar.url))
        return web.Response(status=404)

    async def handle_bg_lana(self, request: web.Request) -> web.StreamResponse:
        bg_file = BASE_DIR / "dashboard" / "bg_lana.jpg"
        if bg_file.exists():
            return web.FileResponse(bg_file)
        return web.Response(status=404)

    async def handle_athi_img(self, request: web.Request) -> web.StreamResponse:
        f = BASE_DIR / "dashboard" / "athi.jpg"
        if f.exists():
            return web.FileResponse(f)
        return web.Response(status=404)

    async def handle_yadz_img(self, request: web.Request) -> web.StreamResponse:
        f = BASE_DIR / "dashboard" / "yadz.jpg"
        if f.exists():
            return web.FileResponse(f)
        return web.Response(status=404)

    async def handle_swarm_init(self, request: web.Request) -> web.StreamResponse:
        f = BASE_DIR / "dashboard" / "swarm-init.js"
        if f.exists():
            return web.FileResponse(f)
        return web.Response(status=404)

    async def handle_api_status(self, request: web.Request) -> web.Response:
        avatar_url = str(self.user.display_avatar.url) if (self.user and self.user.display_avatar) else "https://cdn.discordapp.com/avatars/1566582982167232634/8753e92c208ad90a8d7227b97c1ac283.png?size=256"
        total_members = sum(g.member_count or 0 for g in self.guilds)
        return json_cors({
            "status": "online",
            "bot": "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛",
            "bot_name": "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛",
            "bot_display_name": "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛",
            "bot_avatar": avatar_url,
            "servers": len(self.guilds),
            "total_members": total_members,
            "users": total_members,
            "latency_ms": safe_latency(self.latency)
        })

    async def handle_api_live(self, request: web.Request) -> web.Response:
        gid_param = request.query.get("guild_id")
        gid = int(gid_param) if (gid_param and gid_param.isdigit()) else None
        guild = self.get_target_guild(gid)
        bot_avatar_url = str(self.user.display_avatar.url) if (self.user and self.user.display_avatar) else "https://cdn.discordapp.com/avatars/1566582982167232634/8753e92c208ad90a8d7227b97c1ac283.png?size=256"

        # Build all_guilds list for the multi-server switcher
        all_guilds = []
        for g in self.guilds:
            g_vc = g.voice_client
            is_act = bool(g_vc and (g_vc.is_playing() or g_vc.is_paused()))
            is_conn = bool(g_vc and g_vc.is_connected())
            cur_t = self.current_track.get(g.id)
            cur_title = cur_t.title if (cur_t and is_act) else None
            is_own = (g.id in {1459166857734127759, 1565434460277711018}) or (self.owner_id and g.owner_id == self.owner_id)
            all_guilds.append({
                "id": str(g.id),
                "name": g.name,
                "icon": str(g.icon.url) if g.icon else None,
                "members": g.member_count or 0,
                "is_playing": is_act,
                "is_connected": is_conn,
                "voice_channel": g_vc.channel.name if (g_vc and g_vc.channel) else None,
                "voice_channel_id": str(g_vc.channel.id) if (g_vc and g_vc.channel) else None,
                "current_song": cur_title,
                "is_owner_server": is_own,
                "is_selected": bool(guild and g.id == guild.id)
            })
        all_guilds.sort(key=lambda x: (not x["is_selected"], not x["is_playing"], not x["is_owner_server"], x["name"].lower()))

        if not guild:
            return json_cors({
                "is_online": True,
                "bot_name": "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛",
                "bot_display_name": "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛",
                "bot_avatar": bot_avatar_url,
                "guild_id": None,
                "guild_name": "No Server Connected",
                "is_connected": False,
                "voice_channel": None,
                "voice_channel_id": None,
                "voice_channels": [],
                "listeners_count": 0,
                "current_track": None,
                "is_playing": False,
                "is_paused": False,
                "volume": 100,
                "autoplay": False,
                "mode_247": False,
                "filter": "",
                "queue": [],
                "history": [],
                "all_guilds": all_guilds,
                "stats": {
                    "servers": len(self.guilds),
                    "total_members": sum(g.member_count or 0 for g in self.guilds),
                    "users": sum(g.member_count or 0 for g in self.guilds),
                    "latency_ms": safe_latency(self.latency),
                    "queue_count": 0
                }
            })

        vc = guild.voice_client
        is_playing = bool(vc and vc.is_playing())
        is_paused = bool(vc and vc.is_paused())
        is_connected = bool(vc and vc.is_connected())
        current = self.current_track.get(guild.id)
        cur_data = None
        if current and (is_playing or is_paused):
            dur_sec = parse_duration_to_seconds(current.duration)
            elapsed_sec = get_track_elapsed_sec(self, guild.id)
            if dur_sec > 0 and elapsed_sec > dur_sec:
                elapsed_sec = dur_sec
            vid_id = getattr(current, "video_id", None)
            if not vid_id and current.webpage_url:
                vm = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11})', current.webpage_url)
                if vm:
                    vid_id = vm.group(1)

            cur_data = {
                "title": current.title,
                "uploader": current.uploader,
                "duration": current.duration,
                "duration_sec": dur_sec,
                "elapsed_sec": elapsed_sec,
                "thumbnail": current.thumbnail,
                "webpage_url": current.webpage_url,
                "requester": current.requester,
                "is_url": current.is_url,
                "video_id": vid_id
            }

        vol_pct = int(self.volume.get(guild.id, 1.0) * 100)
        v_chan = vc.channel.name if (vc and vc.channel) else None
        v_chan_id = str(vc.channel.id) if (vc and vc.channel) else None
        listeners = len([m for m in vc.channel.members if not m.bot]) if (vc and vc.channel) else 0

        v_channels = []
        for vc_item in guild.voice_channels:
            v_channels.append({
                "id": str(vc_item.id),
                "name": vc_item.name,
                "members": len([m for m in vc_item.members if not m.bot]),
                "is_current": bool(vc and vc.channel and vc.channel.id == vc_item.id)
            })

        q_data = [
            {
                "title": t.title,
                "duration": t.duration,
                "uploader": t.uploader,
                "thumbnail": t.thumbnail,
                "requester": t.requester
            }
            for t in list(self.queues[guild.id])[:15]
        ]

        h_data = [
            {
                "title": t.title,
                "duration": t.duration,
                "uploader": t.uploader,
                "thumbnail": t.thumbnail
            }
            for t in self.history[guild.id][:10]
        ]

        return json_cors({
            "is_online": True,
            "bot_name": "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛",
            "bot_display_name": "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛",
            "bot_avatar": bot_avatar_url,
            "guild_id": str(guild.id),
            "guild_name": guild.name,
            "is_connected": is_connected,
            "voice_channel": v_chan,
            "voice_channel_id": v_chan_id,
            "voice_channels": v_channels,
            "listeners_count": listeners,
            "current_track": cur_data,
            "is_playing": is_playing,
            "is_paused": is_paused,
            "volume": vol_pct,
            "autoplay": guild.id in self.autoplay,
            "mode_247": guild.id in self.mode_247,
            "filter": self.filters.get(guild.id, ""),
            "queue": q_data,
            "history": h_data,
            "all_guilds": all_guilds,
            "stats": {
                "servers": len(self.guilds),
                "total_members": sum(g.member_count or 0 for g in self.guilds),
                "users": sum(g.member_count or 0 for g in self.guilds),
                "latency_ms": safe_latency(self.latency),
                "queue_count": len(self.queues[guild.id])
            }
        })

    async def handle_api_pause(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        guild = self.get_target_guild(gid)
        if not guild or not guild.voice_client:
            return json_cors({"success": False, "error": "Bot not connected to voice in server"}, status=400)
        vc = guild.voice_client
        if vc.is_playing():
            vc.pause()
            self.pause_start_time[guild.id] = time.time()
            return json_cors({"success": True, "state": "paused"})
        elif vc.is_paused():
            vc.resume()
            if self.pause_start_time.get(guild.id, 0) > 0:
                self.total_paused_duration[guild.id] += time.time() - self.pause_start_time[guild.id]
                self.pause_start_time[guild.id] = 0.0
            return json_cors({"success": True, "state": "playing"})
        return json_cors({"success": False, "error": "Nothing active to pause/resume"}, status=400)

    async def handle_api_skip(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        guild = self.get_target_guild(gid)
        if not guild or not guild.voice_client:
            return json_cors({"success": False, "error": "Bot not connected to voice"}, status=400)
        vc = guild.voice_client
        if vc.is_playing() or vc.is_paused():
            vc.stop()
            return json_cors({"success": True, "message": "Skipped track"})
        return json_cors({"success": False, "error": "Nothing is playing"}, status=400)

    async def handle_api_prev(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        guild = self.get_target_guild(gid)
        if not guild:
            return json_cors({"success": False, "error": "No guild found"}, status=400)
        hist = self.history.get(guild.id, [])
        if len(hist) < 2:
            return json_cors({"success": False, "error": "No previous track in history"}, status=400)
        prev_track = hist[1]
        self.queues[guild.id].appendleft(prev_track)
        vc = guild.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
        return json_cors({"success": True, "title": prev_track.title})

    async def handle_api_volume(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        vol_val = data.get("volume", 100)
        try:
            vol_pct = max(0, min(200, int(vol_val)))
        except Exception:
            vol_pct = 100
        guild = self.get_target_guild(gid)
        if not guild:
            return json_cors({"success": False, "error": "No guild found"}, status=400)
        vol_float = round(vol_pct / 100.0, 2)
        self.volume[guild.id] = vol_float
        vc = guild.voice_client
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = vol_float
        return json_cors({"success": True, "volume": vol_pct})

    async def handle_api_shuffle(self, request: web.Request) -> web.Response:
        import random
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        guild = self.get_target_guild(gid)
        if not guild:
            return json_cors({"success": False, "error": "No guild found"}, status=400)
        q = self.queues[guild.id]
        if len(q) < 2:
            return json_cors({"success": False, "error": "Need at least 2 tracks in queue to shuffle"}, status=400)
        items = list(q)
        random.shuffle(items)
        self.queues[guild.id] = deque(items)
        return json_cors({"success": True, "count": len(items)})

    async def handle_api_autoplay(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        guild = self.get_target_guild(gid)
        if not guild:
            return json_cors({"success": False, "error": "No guild found"}, status=400)
        if guild.id in self.autoplay:
            self.autoplay.remove(guild.id)
            status = False
        else:
            self.autoplay.add(guild.id)
            status = True
            if guild.id in self.current_track:
                async def _prequeue():
                    similar = await fetch_similar_tracks(guild.id, count=5, requester="Autoplay 📻")
                    if similar:
                        for t in similar:
                            self.queues[guild.id].append(t)
                        channel = self.channels.get(guild.id)
                        if channel:
                            embed = discord.Embed(
                                title="📻 Autoplay Playlist Added",
                                description="\n".join(f"`{i}.` **[{t.title}]({t.webpage_url or ''})** (`{t.duration}`)" for i, t in enumerate(similar, 1)),
                                color=discord.Color.from_rgb(46, 204, 113)
                            )
                            embed.set_footer(text=f"Queued {len(similar)} continuous similar songs • No repeats")
                            await channel.send(embed=embed)
                asyncio.create_task(_prequeue())
        return json_cors({"success": True, "autoplay": status})

    async def handle_api_play(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        query = data.get("query", "").strip()
        if not query:
            return json_cors({"success": False, "error": "No song query provided"}, status=400)
        gid = data.get("guild_id")
        cid = data.get("channel_id")
        guild = self.get_target_guild(gid)
        if not guild:
            return json_cors({"success": False, "error": "Bot is not in any server"}, status=400)

        target_vc = None
        if cid:
            try:
                target_vc = guild.get_channel(int(cid))
            except Exception:
                pass

        vc = guild.voice_client
        if not vc or not vc.is_connected():
            if not target_vc:
                for vc_chan in guild.voice_channels:
                    if [m for m in vc_chan.members if not m.bot]:
                        target_vc = vc_chan
                        break
            if not target_vc and guild.voice_channels:
                target_vc = guild.voice_channels[0]
            if target_vc:
                if vc:
                    try:
                        await vc.disconnect(force=True)
                    except Exception:
                        pass
                self.authorized_vc_moves[guild.id] = time.time() + 10.0
                vc = await target_vc.connect(reconnect=True)
                if guild.id in self.mode_247:
                    self.mode_247_channels[guild.id] = target_vc.id
                    self.save_247_config()
                asyncio.create_task(set_vc_status(target_vc.id, "♫ /play to listen to songs"))
            else:
                return json_cors({"success": False, "error": "No voice channel available in server"}, status=400)
        elif target_vc and vc.channel and vc.channel.id != target_vc.id:
            self.authorized_vc_moves[guild.id] = time.time() + 10.0
            await vc.move_to(target_vc)
            if guild.id in self.mode_247:
                self.mode_247_channels[guild.id] = target_vc.id
                self.save_247_config()
            asyncio.create_task(set_vc_status(target_vc.id, "♫ /play to listen to songs"))

        try:
            loop = asyncio.get_running_loop()
            track = await loop.run_in_executor(None, extract_youtube_track, query, "Web Dashboard ⚡")
        except Exception as e:
            return json_cors({"success": False, "error": f"Could not load song: {e}"}, status=400)

        self.queues[guild.id].append(track)
        pos = len(self.queues[guild.id])
        if not (vc.is_playing() or vc.is_paused()):
            asyncio.create_task(play_next(guild.id))
        return json_cors({"success": True, "track": track.title, "position": pos})

    async def handle_api_join(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        cid = data.get("channel_id")
        guild = self.get_target_guild(gid)
        if not guild:
            return json_cors({"success": False, "error": "No server found"}, status=400)

        target_vc = None
        if cid:
            try:
                target_vc = guild.get_channel(int(cid))
            except Exception:
                pass

        if not target_vc:
            for vc_chan in guild.voice_channels:
                if [m for m in vc_chan.members if not m.bot]:
                    target_vc = vc_chan
                    break

        if not target_vc and guild.voice_channels:
            target_vc = guild.voice_channels[0]

        if not target_vc:
            return json_cors({"success": False, "error": f"No voice channels available in {guild.name}"}, status=400)

        try:
            vc = guild.voice_client
            was_moved = False
            already_there = False

            if vc and vc.is_connected():
                if vc.channel and vc.channel.id == target_vc.id:
                    already_there = True
                else:
                    self.authorized_vc_moves[guild.id] = time.time() + 10.0
                    await vc.move_to(target_vc)
                    was_moved = True
            else:
                if vc:
                    try:
                        await vc.disconnect(force=True)
                    except Exception:
                        pass
                self.authorized_vc_moves[guild.id] = time.time() + 10.0
                vc = await target_vc.connect(reconnect=True)

            if guild.id in self.mode_247:
                self.mode_247_channels[guild.id] = target_vc.id
                self.save_247_config()

            asyncio.create_task(set_vc_status(target_vc.id, "♫ /play to listen to songs"))

            msg = f"Already connected to {target_vc.name}" if already_there else (f"Dragged bot into {target_vc.name}" if was_moved else f"Connected to {target_vc.name}")

            return json_cors({
                "success": True,
                "message": msg,
                "channel_id": str(target_vc.id),
                "channel_name": target_vc.name,
                "guild_id": str(guild.id),
                "guild_name": guild.name,
                "is_connected": True,
                "was_moved": was_moved,
                "already_connected": already_there
            })
        except Exception as e:
            print(f"Error joining voice in {guild.name}: {e}")
            return json_cors({"success": False, "error": f"Could not connect: {e}"}, status=500)

    async def handle_api_disconnect(self, request: web.Request) -> web.Response:
        data = await request.json() if request.can_read_body else {}
        gid = data.get("guild_id")
        guild = self.get_target_guild(gid)
        if not guild or not guild.voice_client:
            return json_cors({"success": False, "error": "Bot is not connected to voice in this server"}, status=400)

        if guild.id in self.mode_247:
            self.mode_247.discard(guild.id)
            self.mode_247_channels.pop(guild.id, None)
            self.save_247_config()

        vc = guild.voice_client
        if vc.channel:
            asyncio.create_task(set_vc_status(vc.channel.id, "♫ /play to listen to songs"))
        await vc.disconnect()
        return json_cors({"success": True, "message": f"Disconnected from {guild.name}"})

    async def handle_api_import(self, request: web.Request) -> web.Response:
        reader = await request.multipart()
        guild_id = None
        imports_dir = BASE_DIR / "music" / "imports"
        imports_dir.mkdir(parents=True, exist_ok=True)
        saved_file = None
        orig_filename = "Imported Track"

        while True:
            part = await reader.next()
            if part is None:
                break
            if part.name == 'guild_id':
                val = await part.text()
                if val and val.isdigit():
                    guild_id = int(val)
            elif part.name == 'file':
                orig_filename = part.filename or "uploaded_media"
                ext = Path(orig_filename).suffix.lower()
                clean_stem = re.sub(r'[^\w\s\-\.\(\)]', '', Path(orig_filename).stem).strip() or "Imported_Track"
                saved_file = imports_dir / f"{clean_stem}_{int(time.time())}{ext}"
                with open(saved_file, 'wb') as f:
                    while True:
                        chunk = await part.read_chunk(size=65536)
                        if not chunk:
                            break
                        f.write(chunk)

        if not saved_file or not saved_file.exists():
            return json_cors({"success": False, "error": "No file uploaded"}, status=400)

        guild = self.get_target_guild(guild_id)
        if not guild:
            return json_cors({"success": False, "error": "No active server connected"}, status=400)

        vc = guild.voice_client
        if not vc or not vc.is_connected():
            target_vc = None
            for vc_chan in guild.voice_channels:
                if [m for m in vc_chan.members if not m.bot]:
                    target_vc = vc_chan
                    break
            if not target_vc and guild.voice_channels:
                target_vc = guild.voice_channels[0]
            if not target_vc:
                return json_cors({"success": False, "error": "No voice channels available in this server"}, status=400)
            try:
                vc = await target_vc.connect(reconnect=True)
            except Exception as e:
                return json_cors({"success": False, "error": f"Could not connect to voice: {e}"}, status=500)

        dur_str, _ = get_media_duration_str(saved_file)
        ext = saved_file.suffix.lower()
        is_video = ext in {".mp4", ".webm", ".mkv", ".mov", ".avi", ".flv"}
        track_type = "🎬 Video Audio" if is_video else "🎵 MP3 Audio"
        default_thumb = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80" if is_video else "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&auto=format&fit=crop&q=80"

        clean_title = Path(orig_filename).stem
        track = Track(
            title=clean_title,
            source=str(saved_file),
            is_url=False,
            duration=dur_str,
            thumbnail=default_thumb,
            uploader=f"Web Import ({track_type})",
            requester="Web Dashboard",
        )

        self.queues[guild.id].append(track)
        pos = len(self.queues[guild.id])

        if not (vc.is_playing() or vc.is_paused()):
            asyncio.create_task(play_next(guild.id))

        return json_cors({
            "success": True,
            "track": track.title,
            "duration": dur_str,
            "type": track_type,
            "position": pos
        })


bot = MusicBot()


def find_tracks(query: str) -> list[Path]:
    if not query or Path(query).name != query:
        return []

    available = [
        path for path in MUSIC_DIR.iterdir()
        if path.is_file() and path.suffix.lower() in SUPPORTED_FORMATS
    ]
    normalized_query = query.casefold().strip()
    exact_matches = [
        path for path in available
        if path.name.casefold() == normalized_query
        or path.stem.casefold() == normalized_query
    ]
    if exact_matches:
        return exact_matches
    return [path for path in available if normalized_query in path.stem.casefold()]


def is_youtube_url(value: str) -> bool:
    try:
        parsed = urlparse(value)
        port = parsed.port
    except ValueError:
        return False
    return (
        parsed.scheme == "https"
        and parsed.hostname in YOUTUBE_HOSTS
        and bool(parsed.path.strip("/"))
        and parsed.username is None
        and parsed.password is None
        and port in (None, 443)
    )


def create_track_added_embed(track: Track, position: int) -> discord.Embed:
    embed = discord.Embed(
        title="🎵 Track Added",
        description=f"**[{track.title}]({track.webpage_url or 'https://youtube.com'})** has been queued\n\n**Added By** {track.requester}",
        color=discord.Color.from_rgb(47, 49, 54),
    )
    if track.thumbnail:
        embed.set_thumbnail(url=track.thumbnail)
    embed.add_field(name="Position in Queue", value=str(position), inline=True)
    embed.add_field(name="Duration", value=f"`{track.duration}`", inline=True)
    web_url = os.getenv("DASHBOARD_URL", "http://localhost:5050")
    embed.set_footer(text=f"𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 • Web App: {web_url}")
    return embed


def create_now_playing_embed(track: Track) -> discord.Embed:
    embed = discord.Embed(
        title="🎶 Now Playing",
        description=f"**[{track.title}]({track.webpage_url or 'https://youtube.com'})**",
        color=discord.Color.from_rgb(32, 34, 37),
    )
    if track.thumbnail:
        embed.set_thumbnail(url=track.thumbnail)

    embed.add_field(name="Duration", value=f"`{track.duration}`", inline=True)
    embed.add_field(name="Source", value="🔴 YouTube" if track.is_url else "📁 Local", inline=True)
    embed.add_field(name="Channel", value=f"`{track.uploader}`", inline=True)
    embed.add_field(name="Requested by", value=track.requester, inline=True)
    web_url = os.getenv("DASHBOARD_URL", "http://localhost:5050")
    embed.set_footer(text=f"Playback Controls • 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 • Web: {web_url}")
    return embed


class StreamView(discord.ui.View):
    def __init__(self, youtube_url: str = None, watch_together_url: str = None):
        super().__init__(timeout=None)
        if youtube_url:
            self.add_item(discord.ui.Button(label="Watch on YouTube", emoji="📺", url=youtube_url, style=discord.ButtonStyle.link))
        if watch_together_url:
            self.add_item(discord.ui.Button(label="Watch Together (Voice)", emoji="🚀", url=watch_together_url, style=discord.ButtonStyle.link))
        self.add_item(discord.ui.Button(label="Web Dashboard 720P", emoji="🌐", url=os.getenv("DASHBOARD_URL", "http://localhost:5050"), style=discord.ButtonStyle.link))


async def perform_stream(interaction: discord.Interaction, query: str = None) -> None:
    try:
        if not interaction.response.is_done():
            await interaction.response.defer()
    except Exception:
        pass

    guild_id = interaction.guild_id
    requester_name = interaction.user.display_name

    track = None
    if query:
        try:
            track = await asyncio.to_thread(extract_youtube_track, query, requester_name)
        except Exception as e:
            await interaction.followup.send(f"❌ Could not load video stream: `{e}`", ephemeral=True)
            return
    else:
        track = bot.current_track.get(guild_id)
        if not track:
            track = await asyncio.to_thread(extract_youtube_track, "hindi item songs", requester_name)

    watch_together_url = None
    # Connect bot to voice if user is connected
    if interaction.user.voice and interaction.user.voice.channel:
        vc_channel = interaction.user.voice.channel
        if not interaction.guild.voice_client:
            try:
                await vc_channel.connect()
            except Exception:
                pass

        # Try to generate Discord Watch Together Activity invite
        try:
            invite = await vc_channel.create_invite(
                target_type=discord.InviteTarget.embedded_application,
                target_application_id=880218394199220334,
                max_age=86400,
                max_uses=0
            )
            watch_together_url = invite.url
        except Exception as e:
            print(f"Watch together notice: {e}")

        # Start playback if requested new track
        if query:
            bot.queues[guild_id].appendleft(track)
            vc = interaction.guild.voice_client
            if vc and (not vc.is_playing() and not vc.is_paused()):
                await play_next(guild_id)

    embed = discord.Embed(
        title="📺 720P 30FPS LIVE • YouTube Video Stream",
        description=(
            f"> **❯ Video Title** : [{track.title}]({track.webpage_url or 'https://youtube.com'})\n"
            f"> **❯ Channel** : `{track.uploader}`\n"
            f"> **❯ Duration** : `{track.duration}`\n"
            f"> **❯ Stream Quality** : `720P 30FPS LIVE • Lossless Audio`\n"
            f"> **❯ Requested by** : {interaction.user.mention}\n\n"
            "*Streaming audio in voice channel & live video stream on YouTube and Discord Watch Together!*"
        ),
        color=discord.Color.from_rgb(255, 0, 0)
    )
    if track.thumbnail:
        embed.set_image(url=track.thumbnail)
    embed.set_footer(text="𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 Live Streaming Engine • 720P 30FPS HD")

    view = StreamView(youtube_url=track.webpage_url, watch_together_url=watch_together_url)
    await interaction.followup.send(embed=embed, view=view)


class MusicControls(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=None)
        self.guild_id = guild_id
        if guild_id in bot.autoplay:
            self.autoplay_btn.style = discord.ButtonStyle.success
            self.autoplay_btn.label = "Autoplay ON"
        web_url = os.getenv("DASHBOARD_URL", "http://localhost:5050")
        self.add_item(discord.ui.Button(label="Web Dashboard", emoji="🌐", url=web_url, style=discord.ButtonStyle.link, row=4))

    # --- ROW 0: Playback Primary ---
    @discord.ui.button(label="Prev", emoji="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        hist = bot.history.get(self.guild_id, [])
        if len(hist) < 2:
            await interaction.response.send_message("❌ No previous track found in history.", ephemeral=True)
            return
        prev_track = hist[1]
        bot.queues[self.guild_id].appendleft(prev_track)
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
        await interaction.response.send_message(f"⏮️ Playing previous track: **{prev_track.title}**", ephemeral=True)

    @discord.ui.button(label="Pause", emoji="⏸️", style=discord.ButtonStyle.secondary, row=0)
    async def pause_resume(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if not vc:
            await interaction.response.send_message("Not connected to a voice channel.", ephemeral=True)
            return

        if vc.is_playing():
            vc.pause()
            bot.pause_start_time[self.guild_id] = time.time()
            button.label = "Resume"
            button.emoji = "▶️"
            button.style = discord.ButtonStyle.success
            await interaction.response.edit_message(view=self)
        elif vc.is_paused():
            vc.resume()
            if bot.pause_start_time.get(self.guild_id, 0) > 0:
                bot.total_paused_duration[self.guild_id] += time.time() - bot.pause_start_time[self.guild_id]
                bot.pause_start_time[self.guild_id] = 0.0
            button.label = "Pause"
            button.emoji = "⏸️"
            button.style = discord.ButtonStyle.secondary
            await interaction.response.edit_message(view=self)
        else:
            await interaction.response.send_message("Nothing is playing.", ephemeral=True)

    @discord.ui.button(emoji="🤍", style=discord.ButtonStyle.secondary, row=0)
    async def favorite_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
            return
        favs = bot.favorites[interaction.user.id]
        if any(f.title == track.title for f in favs):
            bot.favorites[interaction.user.id] = [f for f in favs if f.title != track.title]
            button.emoji = "🤍"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"💔 Removed **{track.title}** from favorites.", ephemeral=True)
        else:
            favs.append(track)
            button.emoji = "💖"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"💖 Added **{track.title}** to favorites!", ephemeral=True)

    # --- ROW 1: Skip & Stop ---
    @discord.ui.button(label="Skip", emoji="⏭️", style=discord.ButtonStyle.secondary, row=1)
    async def skip(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            await interaction.response.send_message("⏭️ Skipped current track.", ephemeral=True)
        else:
            await interaction.response.send_message("Nothing is playing.", ephemeral=True)

    @discord.ui.button(label="Stop", emoji="⏹️", style=discord.ButtonStyle.danger, row=1)
    async def stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        bot.queues[self.guild_id].clear()
        bot.current_track.pop(self.guild_id, None)
        bot.track_start_time[self.guild_id] = 0.0
        bot.pause_start_time[self.guild_id] = 0.0
        bot.total_paused_duration[self.guild_id] = 0.0
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc:
            if vc.channel:
                asyncio.create_task(set_vc_status(vc.channel.id, "♫ /play to listen to songs"))
            if self.guild_id not in bot.mode_247:
                await vc.disconnect()
            else:
                vc.stop()
            asyncio.create_task(update_presence_for_guild(self.guild_id, track=None))
            await interaction.response.send_message("⏹️ Playback stopped and queue cleared.", ephemeral=True)
        else:
            asyncio.create_task(update_presence_for_guild(self.guild_id, track=None))
            await interaction.response.send_message("Not connected.", ephemeral=True)

    # --- ROW 2: Volume Controls ---
    @discord.ui.button(label="Mute", emoji="🔇", style=discord.ButtonStyle.secondary, row=2)
    async def mute(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = 0.0
            bot.volume[self.guild_id] = 0.0
            await interaction.response.send_message("🔇 Audio muted.", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    @discord.ui.button(label="Vol -", emoji="🔉", style=discord.ButtonStyle.secondary, row=2)
    async def vol_down(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = max(0.1, round(vc.source.volume - 0.2, 2))
            bot.volume[self.guild_id] = vc.source.volume
            await interaction.response.send_message(f"🔉 Volume: {int(vc.source.volume * 100)}%", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    @discord.ui.button(label="100%", style=discord.ButtonStyle.secondary, row=2)
    async def vol_reset(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = 1.0
            bot.volume[self.guild_id] = 1.0
            await interaction.response.send_message("🔊 Volume set to 100%.", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    @discord.ui.button(label="Vol +", emoji="🔊", style=discord.ButtonStyle.secondary, row=2)
    async def vol_up(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = min(2.0, round(vc.source.volume + 0.2, 2))
            bot.volume[self.guild_id] = vc.source.volume
            await interaction.response.send_message(f"🔊 Volume: {int(vc.source.volume * 100)}%", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    @discord.ui.button(label="Max", emoji="🔊", style=discord.ButtonStyle.secondary, row=2)
    async def vol_max(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = 2.0
            bot.volume[self.guild_id] = 2.0
            await interaction.response.send_message("🔊 Volume set to MAX (200%).", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    # --- ROW 3: Extras (Queue, Shuffle, Lyrics, Save, Share) ---
    @discord.ui.button(label="Queue", emoji="🔄", style=discord.ButtonStyle.secondary, row=3)
    async def show_queue(self, interaction: discord.Interaction, button: discord.ui.Button):
        queue = list(bot.queues[self.guild_id])
        if not queue:
            msg = "The queue is empty."
        else:
            msg = "Upcoming tracks:\n" + "\n".join(
                f"{idx}. `{t.title}` (`{t.duration}`)" for idx, t in enumerate(queue[:10], start=1)
            )
        await interaction.response.send_message(msg, ephemeral=True)

    @discord.ui.button(label="Shuffle", emoji="🔀", style=discord.ButtonStyle.secondary, row=3)
    async def shuffle_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        import random
        queue = bot.queues[self.guild_id]
        if len(queue) < 2:
            await interaction.response.send_message("❌ Need at least 2 tracks in queue to shuffle.", ephemeral=True)
            return
        tracks_list = list(queue)
        random.shuffle(tracks_list)
        bot.queues[self.guild_id] = deque(tracks_list)
        await interaction.response.send_message(f"🔀 Shuffled **{len(tracks_list)}** tracks!", ephemeral=True)

    @discord.ui.button(label="Lyrics", emoji="📜", style=discord.ButtonStyle.secondary, row=3)
    async def lyrics_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        embed = discord.Embed(
            title=f"📜 Song Details • {track.title[:45]}",
            description=f"**Title**: [{track.title}]({track.webpage_url or 'https://youtube.com'})\n**Artist/Channel**: `{track.uploader}`\n**Duration**: `{track.duration}`\n**Requested by**: {track.requester}\n\n*Live streaming synced with web dashboard!*",
            color=discord.Color.from_rgb(245, 197, 24)
        )
        if track.thumbnail:
            embed.set_thumbnail(url=track.thumbnail)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="Save", emoji="💾", style=discord.ButtonStyle.secondary, row=3)
    async def save_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        embed = discord.Embed(
            title="📥 Saved Track",
            description=f"**[{track.title}]({track.webpage_url or 'https://youtube.com'})**",
            color=discord.Color.from_rgb(245, 197, 24)
        )
        if track.thumbnail:
            embed.set_thumbnail(url=track.thumbnail)
        embed.add_field(name="Duration", value=f"`{track.duration}`", inline=True)
        embed.add_field(name="Channel", value=f"`{track.uploader}`", inline=True)
        embed.set_footer(text=f"Saved from {interaction.guild.name} • 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛")
        try:
            await interaction.user.send(embed=embed)
            await interaction.response.send_message("📬 Sent song details to your DMs!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Please enable DMs from server members.", ephemeral=True)

    @discord.ui.button(label="Share", emoji="📤", style=discord.ButtonStyle.secondary, row=3)
    async def share_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"🎶 **Now Playing**: [{track.title}]({track.webpage_url or 'https://youtube.com'}) (Shared by {interaction.user.mention})"
        )

    # --- ROW 4: Autoplay & Stream ---
    @discord.ui.button(label="Autoplay", emoji="📻", style=discord.ButtonStyle.secondary, row=4)
    async def autoplay_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.guild_id in bot.autoplay:
            bot.autoplay.remove(self.guild_id)
            button.style = discord.ButtonStyle.secondary
            button.label = "Autoplay"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("📻 **Autoplay disabled**.", ephemeral=True)
        else:
            bot.autoplay.add(self.guild_id)
            button.style = discord.ButtonStyle.success
            button.label = "Autoplay ON"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("📻 **Autoplay enabled**! Continuously playing all similar tracks without repeating.", ephemeral=True)
            if self.guild_id in bot.current_track:
                async def _prequeue():
                    channel = bot.channels.get(self.guild_id)
                    if channel:
                        await channel.send("📻 Finding 5 similar songs for **Autoplay Playlist**...")
                    similar = await fetch_similar_tracks(self.guild_id, count=5, requester="Autoplay 📻")
                    if similar:
                        for t in similar:
                            bot.queues[self.guild_id].append(t)
                        if channel:
                            embed = discord.Embed(
                                title="📻 Autoplay Playlist Added",
                                description="\n".join(f"`{i}.` **[{t.title}]({t.webpage_url or ''})** (`{t.duration}`)" for i, t in enumerate(similar, 1)),
                                color=discord.Color.from_rgb(46, 204, 113)
                            )
                            embed.set_footer(text=f"Queued {len(similar)} continuous similar songs • No repeats")
                            await channel.send(embed=embed)
                asyncio.create_task(_prequeue())

    @discord.ui.button(label="Stream", emoji="📺", style=discord.ButtonStyle.primary, row=4)
    async def stream_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await perform_stream(interaction, query=None)



class PlaybackControls(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=None)
        self.guild_id = guild_id

    # --- ROW 0: Prev, Pause/Resume, Favorite ---
    @discord.ui.button(label="Prev", emoji="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        hist = bot.history.get(self.guild_id, [])
        if len(hist) < 2:
            await interaction.response.send_message("❌ No previous track found in history.", ephemeral=True)
            return
        prev_track = hist[1]
        bot.queues[self.guild_id].appendleft(prev_track)
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
        await interaction.response.send_message(f"⏮️ Playing previous track: **{prev_track.title}**", ephemeral=True)

    @discord.ui.button(label="Pause", emoji="⏸️", style=discord.ButtonStyle.secondary, row=0)
    async def pause_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if not vc:
            await interaction.response.send_message("Not connected to a voice channel.", ephemeral=True)
            return
        if vc.is_playing():
            vc.pause()
            bot.pause_start_time[self.guild_id] = time.time()
            button.label = "Resume"
            button.emoji = "▶️"
            button.style = discord.ButtonStyle.success
            await interaction.response.edit_message(view=self)
        elif vc.is_paused():
            vc.resume()
            if bot.pause_start_time.get(self.guild_id, 0) > 0:
                bot.total_paused_duration[self.guild_id] += time.time() - bot.pause_start_time[self.guild_id]
                bot.pause_start_time[self.guild_id] = 0.0
            button.label = "Pause"
            button.emoji = "⏸️"
            button.style = discord.ButtonStyle.secondary
            await interaction.response.edit_message(view=self)
        else:
            await interaction.response.send_message("Nothing is playing.", ephemeral=True)

    @discord.ui.button(emoji="🤍", style=discord.ButtonStyle.secondary, row=0)
    async def favorite_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
            return
        favs = bot.favorites[interaction.user.id]
        if any(f.title == track.title for f in favs):
            bot.favorites[interaction.user.id] = [f for f in favs if f.title != track.title]
            button.emoji = "🤍"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"💔 Removed **{track.title}** from favorites.", ephemeral=True)
        else:
            favs.append(track)
            button.emoji = "💖"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"💖 Added **{track.title}** to favorites!", ephemeral=True)

    # --- ROW 1: Skip, Stop ---
    @discord.ui.button(label="Skip", emoji="⏭️", style=discord.ButtonStyle.secondary, row=1)
    async def skip_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and (vc.is_playing() or vc.is_paused()):
            vc.stop()
            await interaction.response.send_message("⏭️ Skipped current track.", ephemeral=True)
        else:
            await interaction.response.send_message("Nothing is playing.", ephemeral=True)

    @discord.ui.button(label="Stop", emoji="⏹️", style=discord.ButtonStyle.danger, row=1)
    async def stop_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        bot.queues[self.guild_id].clear()
        bot.current_track.pop(self.guild_id, None)
        bot.track_start_time[self.guild_id] = 0.0
        bot.pause_start_time[self.guild_id] = 0.0
        bot.total_paused_duration[self.guild_id] = 0.0
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc:
            if vc.channel:
                asyncio.create_task(set_vc_status(vc.channel.id, "♫ /play to listen to songs"))
            if self.guild_id not in bot.mode_247:
                await vc.disconnect()
            else:
                vc.stop()
            asyncio.create_task(update_presence_for_guild(self.guild_id, track=None))
            await interaction.response.send_message("⏹️ Playback stopped and queue cleared.", ephemeral=True)
        else:
            asyncio.create_task(update_presence_for_guild(self.guild_id, track=None))
            await interaction.response.send_message("Not connected.", ephemeral=True)

    # --- ROW 2: Volume Controls (Mute, -, 100%, +) ---
    @discord.ui.button(label="Mute", emoji="🔇", style=discord.ButtonStyle.secondary, row=2)
    async def mute_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = 0.0
            bot.volume[self.guild_id] = 0.0
            await interaction.response.send_message("🔇 Audio muted.", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    @discord.ui.button(label="-", emoji="🔉", style=discord.ButtonStyle.secondary, row=2)
    async def vol_down_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = max(0.1, round(vc.source.volume - 0.2, 2))
            bot.volume[self.guild_id] = vc.source.volume
            await interaction.response.send_message(f"🔉 Volume: {int(vc.source.volume * 100)}%", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    @discord.ui.button(label="100%", style=discord.ButtonStyle.secondary, row=2)
    async def vol_reset_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = 1.0
            bot.volume[self.guild_id] = 1.0
            await interaction.response.send_message("🔊 Volume reset to 100%.", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    @discord.ui.button(label="+", emoji="🔊", style=discord.ButtonStyle.secondary, row=2)
    async def vol_up_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = min(2.0, round(vc.source.volume + 0.2, 2))
            bot.volume[self.guild_id] = vc.source.volume
            await interaction.response.send_message(f"🔊 Volume: {int(vc.source.volume * 100)}%", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)

    # --- ROW 3: Max Volume ---
    @discord.ui.button(label="Max", emoji="🔊", style=discord.ButtonStyle.secondary, row=3)
    async def vol_max_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        vc = interaction.guild.voice_client if interaction.guild else None
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = 2.0
            bot.volume[self.guild_id] = 2.0
            await interaction.response.send_message("🔊 Volume set to MAX (200%).", ephemeral=True)
        else:
            await interaction.response.send_message("Volume control unavailable.", ephemeral=True)


class ExtrasControls(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=None)
        self.guild_id = guild_id
        if guild_id in bot.autoplay:
            self.autoplay_btn.style = discord.ButtonStyle.success
            self.autoplay_btn.label = "Autoplay ON"

    # --- ROW 0: Queue, Shuffle, Lyrics (Matches Screenshot) ---
    @discord.ui.button(label="Queue", emoji="🔄", style=discord.ButtonStyle.secondary, row=0)
    async def queue_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        queue = list(bot.queues[self.guild_id])
        if not queue:
            msg = "The queue is empty."
        else:
            msg = "Upcoming tracks:\n" + "\n".join(
                f"{idx}. `{t.title}` (`{t.duration}`)" for idx, t in enumerate(queue[:10], start=1)
            )
        await interaction.response.send_message(msg, ephemeral=True)

    @discord.ui.button(label="Shuffle", emoji="🔀", style=discord.ButtonStyle.secondary, row=0)
    async def shuffle_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        import random
        queue = bot.queues[self.guild_id]
        if len(queue) < 2:
            await interaction.response.send_message("❌ Need at least 2 tracks in queue to shuffle.", ephemeral=True)
            return
        tracks_list = list(queue)
        random.shuffle(tracks_list)
        bot.queues[self.guild_id] = deque(tracks_list)
        await interaction.response.send_message(f"🔀 Shuffled **{len(tracks_list)}** tracks!", ephemeral=True)

    @discord.ui.button(label="Lyrics", emoji="📜", style=discord.ButtonStyle.secondary, row=0)
    async def lyrics_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        embed = discord.Embed(
            title=f"📜 Song Details • {track.title[:45]}",
            description=f"**Title**: [{track.title}]({track.webpage_url or 'https://youtube.com'})\n**Artist/Channel**: `{track.uploader}`\n**Duration**: `{track.duration}`\n**Requested by**: {track.requester}\n\n*Live streaming synced with web dashboard!*",
            color=discord.Color.from_rgb(245, 197, 24)
        )
        if track.thumbnail:
            embed.set_thumbnail(url=track.thumbnail)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # --- ROW 1: Save, Share (Matches Screenshot) ---
    @discord.ui.button(label="Save", emoji="💾", style=discord.ButtonStyle.secondary, row=1)
    async def save_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        embed = discord.Embed(
            title="📥 Saved Track",
            description=f"**[{track.title}]({track.webpage_url or 'https://youtube.com'})**",
            color=discord.Color.from_rgb(245, 197, 24)
        )
        if track.thumbnail:
            embed.set_thumbnail(url=track.thumbnail)
        embed.add_field(name="Duration", value=f"`{track.duration}`", inline=True)
        embed.add_field(name="Channel", value=f"`{track.uploader}`", inline=True)
        embed.set_footer(text=f"Saved from {interaction.guild.name} • 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛")
        try:
            await interaction.user.send(embed=embed)
            await interaction.response.send_message("📬 Sent song details to your DMs!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Please enable DMs from server members.", ephemeral=True)

    @discord.ui.button(label="Share", emoji="📤", style=discord.ButtonStyle.secondary, row=1)
    async def share_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        track = bot.current_track.get(self.guild_id)
        if not track:
            await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"🎶 **Now Playing**: [{track.title}]({track.webpage_url or 'https://youtube.com'}) (Shared by {interaction.user.mention})"
        )

    # --- ROW 2: Autoplay & Stream Video (Matches Screenshot Image 3) ---
    @discord.ui.button(label="Autoplay", emoji="📻", style=discord.ButtonStyle.secondary, row=2)
    async def autoplay_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.guild_id in bot.autoplay:
            bot.autoplay.remove(self.guild_id)
            button.style = discord.ButtonStyle.secondary
            button.label = "Autoplay"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("📻 **Autoplay disabled**.", ephemeral=True)
        else:
            bot.autoplay.add(self.guild_id)
            button.style = discord.ButtonStyle.success
            button.label = "Autoplay ON"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send("📻 **Autoplay enabled**! Continuously playing all similar tracks without repeating.", ephemeral=True)
            if self.guild_id in bot.current_track:
                async def _prequeue():
                    channel = bot.channels.get(self.guild_id)
                    if channel:
                        await channel.send("📻 Finding 5 similar songs for **Autoplay Playlist**...")
                    similar = await fetch_similar_tracks(self.guild_id, count=5, requester="Autoplay 📻")
                    if similar:
                        for t in similar:
                            bot.queues[self.guild_id].append(t)
                        if channel:
                            embed = discord.Embed(
                                title="📻 Autoplay Playlist Added",
                                description="\n".join(f"`{i}.` **[{t.title}]({t.webpage_url or ''})** (`{t.duration}`)" for i, t in enumerate(similar, 1)),
                                color=discord.Color.from_rgb(46, 204, 113)
                            )
                            embed.set_footer(text=f"Queued {len(similar)} continuous similar songs • No repeats")
                            await channel.send(embed=embed)
                asyncio.create_task(_prequeue())

    @discord.ui.button(label="Stream", emoji="📺", style=discord.ButtonStyle.primary, row=2)
    async def stream_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await perform_stream(interaction, query=None)

def extract_youtube_track(query_or_url: str, requester: str = "Unknown") -> Track:
    options = {
        "format": "bestaudio/best",
        "noplaylist": True,
        "default_search": "ytsearch",
        "quiet": True,
        "no_warnings": True,
    }
    with yt_dlp.YoutubeDL(options) as youtube_dl:
        info = youtube_dl.extract_info(query_or_url, download=False)

    if not isinstance(info, dict):
        raise yt_dlp.utils.DownloadError("No playable audio stream was found.")

    if "entries" in info and info["entries"]:
        info = info["entries"][0]

    if not isinstance(info.get("url"), str):
        raise yt_dlp.utils.DownloadError("No playable audio stream was found.")

    title = info.get("title") or "YouTube audio"
    thumbnail = info.get("thumbnail")
    webpage_url = info.get("webpage_url") or query_or_url
    uploader = info.get("uploader") or info.get("channel") or "YouTube"

    raw_duration = info.get("duration")
    if isinstance(raw_duration, (int, float)):
        m, s = divmod(int(raw_duration), 60)
        h, m = divmod(m, 60)
        duration_str = f"{h:02d}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"
    else:
        duration_str = "00:00"

    video_id = info.get("id")
    if not video_id and webpage_url:
        vm = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11})', webpage_url)
        if vm:
            video_id = vm.group(1)

    return Track(
        title=title,
        source=info["url"],
        is_url=True,
        duration=duration_str,
        thumbnail=thumbnail,
        webpage_url=webpage_url,
        uploader=uploader,
        requester=requester,
        video_id=video_id,
    )


def clean_song_title(title: str) -> str:
    t = re.sub(r'[\(\[\{].*?[\)\]\}]', '', title)
    t = re.sub(r'(?i)(official video|music video|full song|lyric video|lyrics|audio|remix|slowed|reverb|8k|4k|hd|feat\.?|ft\.?)', '', t)
    t = re.sub(r'[^\w\s]', ' ', t)
    return ' '.join(t.lower().split())


def is_duplicate_song(cand_title: str, cand_id: str | None, current_title: str, current_id: str | None, history: list[Track] | None = None) -> bool:
    if cand_id and current_id and cand_id == current_id:
        return True
    c_cand = clean_song_title(cand_title)
    c_curr = clean_song_title(current_title)
    if c_cand and c_curr and (c_cand == c_curr or c_cand in c_curr or c_curr in c_cand):
        return True
    w_cand, w_curr = set(c_cand.split()), set(c_curr.split())
    if w_cand and w_curr:
        overlap = len(w_cand & w_curr) / max(len(w_cand), len(w_curr))
        if overlap > 0.55:
            return True
    if history:
        for past in history:
            if cand_id and past.video_id and cand_id == past.video_id:
                return True
            c_past = clean_song_title(past.title)
            if c_cand and c_past and (c_cand == c_past or c_cand in c_past or c_past in c_cand):
                return True
            w_past = set(c_past.split())
            if w_cand and w_past and (len(w_cand & w_past) / max(len(w_cand), len(w_past))) > 0.55:
                return True
    return False


async def fetch_similar_tracks(guild_id: int, count: int = 1, requester: str = "Autoplay 📻") -> list[Track]:
    current = bot.current_track.get(guild_id)
    if not current:
        hist = bot.history.get(guild_id, [])
        if hist:
            current = hist[0]
    if not current:
        return []

    history = bot.history.get(guild_id, [])
    queued_tracks = list(bot.queues.get(guild_id, []))
    all_known = list(history) + queued_tracks

    video_id = current.video_id
    if not video_id and current.webpage_url:
        vm = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11})', current.webpage_url)
        if vm:
            video_id = vm.group(1)

    loop = asyncio.get_running_loop()
    candidates: list[dict] = []

    # Strategy 1: YouTube Radio Mix (RD list) - official recommendation graph
    if video_id:
        def _get_radio_mix():
            flat_opts = {
                'quiet': True,
                'extract_flat': True,
                'playlist_items': '1-25',
                'no_warnings': True,
            }
            try:
                with yt_dlp.YoutubeDL(flat_opts) as ydl:
                    info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}&list=RD{video_id}", download=False)
                    return info.get('entries', []) if info else []
            except Exception as e:
                print(f"Radio mix fetch warning: {e}")
                return []

        entries = await loop.run_in_executor(None, _get_radio_mix)
        for e in entries:
            if not e:
                continue
            eid = e.get('id')
            title = e.get('title', '')
            if not is_duplicate_song(title, eid, current.title, video_id, all_known):
                candidates.append(e)
                if len(candidates) >= count + 3:
                    break

    # Strategy 2: Fallback search for similar artist / genre songs
    if len(candidates) < count:
        clean_c = clean_song_title(current.title)
        artist_hint = current.uploader if (current.uploader and current.uploader.lower() != "youtube") else clean_c
        query = f"ytsearch15:{artist_hint} similar music playlist"

        def _search_fallback():
            search_opts = {
                'quiet': True,
                'extract_flat': True,
                'playlist_items': '1-15',
                'no_warnings': True,
            }
            try:
                with yt_dlp.YoutubeDL(search_opts) as ydl:
                    info = ydl.extract_info(query, download=False)
                    return info.get('entries', []) if info else []
            except Exception as e:
                print(f"Fallback search warning: {e}")
                return []

        fallback_entries = await loop.run_in_executor(None, _search_fallback)
        for e in fallback_entries:
            if not e:
                continue
            eid = e.get('id')
            title = e.get('title', '')
            if not any(c.get('id') == eid for c in candidates):
                if not is_duplicate_song(title, eid, current.title, video_id, all_known):
                    candidates.append(e)
                    if len(candidates) >= count + 3:
                        break

    # Extract direct playable audio streams for top candidates concurrently
    selected_cands = candidates[:count]
    extract_tasks = []
    for cand in selected_cands:
        cand_id = cand.get('id')
        cand_url = f"https://www.youtube.com/watch?v={cand_id}" if cand_id else cand.get('url')
        if cand_url:
            extract_tasks.append(loop.run_in_executor(None, extract_youtube_track, cand_url, requester))

    extracted = await asyncio.gather(*extract_tasks, return_exceptions=True)
    results: list[Track] = []
    for item in extracted:
        if isinstance(item, Track):
            results.append(item)
            all_known.append(item)
        elif isinstance(item, Exception):
            print(f"Error extracting candidate track: {item}")

    return results


async def set_vc_status(channel_id: int | None, status_text: str | None) -> None:
    if not channel_id:
        return
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        return
    url = f"https://discord.com/api/v10/channels/{channel_id}/voice-status"
    headers = {
        "Authorization": f"Bot {token}",
        "Content-Type": "application/json"
    }
    payload = {"status": (status_text or "")[:100]}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.put(url, headers=headers, json=payload) as resp:
                pass
    except Exception as e:
        print(f"Voice status update error: {e}")


async def refill_autoplay_queue(guild_id: int) -> None:
    if guild_id not in bot.autoplay:
        return
    q = bot.queues[guild_id]
    if len(q) >= 4:
        return
    need = max(1, 4 - len(q))
    try:
        similar = await fetch_similar_tracks(guild_id, count=need, requester="Autoplay 📻")
        if similar:
            for t in similar:
                bot.queues[guild_id].append(t)
            channel = bot.channels.get(guild_id)
            if channel and len(similar) > 0:
                asyncio.create_task(channel.send(f"📻 **Autoplay Refill**: Queued {len(similar)} more similar tracks (Next: **{similar[0].title[:45]}**)"))
    except Exception as e:
        print(f"Autoplay refill warning: {e}")


BOT_OWNER_ID = 1324671125908619276
OWNER_GUILD_IDS = {1459166857734127759, 1565434460277711018}

def is_owner_guild(guild_id: int) -> bool:
    if guild_id in OWNER_GUILD_IDS:
        return True
    guild = bot.get_guild(guild_id)
    if guild and (guild.owner_id == BOT_OWNER_ID or (getattr(bot, 'owner_id', None) and guild.owner_id == bot.owner_id)):
        OWNER_GUILD_IDS.add(guild.id)
        return True
    return False

async def update_presence_for_guild(guild_id: int, track: Track | None = None) -> None:
    """
    Updates the bot's Rich Presence on Discord:
    - When music is playing in the Bot Owner's server (e.g. 𝐙𝐄𝐗𝐈 愛), the song title is displayed on the profile.
    - When music is playing in ANY OTHER SERVER, that other server's song is NEVER shown on the bot's profile.
    - When playback stops or queue finishes in the owner's server, the presence reverts to '/play | 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛'.
    """
    try:
        if is_owner_guild(guild_id):
            if track:
                clean_name = re.sub(r'[\(\[\{].*?[\)\]\}]', '', track.title).strip()
                clean_name = re.sub(r'\s+', ' ', clean_name)
                display_name = clean_name if clean_name else track.title
                await bot.change_presence(
                    status=discord.Status.online,
                    activity=discord.Activity(
                        type=discord.ActivityType.listening,
                        name=f"{display_name[:100]}"
                    )
                )
            else:
                # Check if another owner guild is currently playing
                active_track = None
                for og_id in list(OWNER_GUILD_IDS):
                    if og_id != guild_id and og_id in bot.current_track:
                        og_guild = bot.get_guild(og_id)
                        og_vc = og_guild.voice_client if og_guild else None
                        if og_vc and (og_vc.is_playing() or og_vc.is_paused()):
                            active_track = bot.current_track[og_id]
                            break
                if active_track:
                    clean_name = re.sub(r'[\(\[\{].*?[\)\]\}]', '', active_track.title).strip()
                    clean_name = re.sub(r'\s+', ' ', clean_name)
                    display_name = clean_name if clean_name else active_track.title
                    await bot.change_presence(
                        status=discord.Status.online,
                        activity=discord.Activity(
                            type=discord.ActivityType.listening,
                            name=f"{display_name[:100]}"
                        )
                    )
                else:
                    await bot.change_presence(
                        status=discord.Status.online,
                        activity=discord.Activity(
                            type=discord.ActivityType.listening,
                            name="/play | 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛"
                        )
                    )
        else:
            # Foreign server: never show foreign song on the bot profile
            has_active_owner = False
            for og_id in list(OWNER_GUILD_IDS):
                if og_id in bot.current_track:
                    og_guild = bot.get_guild(og_id)
                    og_vc = og_guild.voice_client if og_guild else None
                    if og_vc and (og_vc.is_playing() or og_vc.is_paused()):
                        has_active_owner = True
                        break
            if not has_active_owner and not track:
                await bot.change_presence(
                    status=discord.Status.online,
                    activity=discord.Activity(
                        type=discord.ActivityType.listening,
                        name="/play | 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛"
                    )
                )
    except Exception as e:
        print(f"Error in update_presence_for_guild: {e}")


async def fetch_autoplay_track(guild_id: int) -> Track | None:
    tracks = await fetch_similar_tracks(guild_id, count=4, requester="Autoplay 📻")
    if tracks:
        for t in tracks[1:]:
            bot.queues[guild_id].append(t)
        return tracks[0]
    return None


async def ensure_voice_connected(interaction: discord.Interaction, member: discord.Member) -> discord.VoiceClient | None:
    voice_client = interaction.guild.voice_client
    if voice_client is None or not voice_client.is_connected():
        if voice_client is not None:
            try:
                await voice_client.disconnect(force=True)
            except Exception:
                pass
        try:
            voice_client = await member.voice.channel.connect(timeout=20.0, reconnect=True)
        except Exception as e:
            msg = f"❌ Could not connect to voice channel `{member.voice.channel.name}`: {e}"
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
            return None
    elif voice_client.channel != member.voice.channel:
        bot.authorized_vc_moves[interaction.guild_id] = time.time() + 5.0
        if interaction.guild_id in bot.mode_247:
            bot.mode_247_channels[interaction.guild_id] = member.voice.channel.id
            bot.save_247_config()
        try:
            await voice_client.move_to(member.voice.channel)
        except Exception:
            pass
    return voice_client


async def play_next(guild_id: int, initial_interaction: discord.Interaction | None = None) -> None:
    guild = bot.get_guild(guild_id)
    voice_client = guild.voice_client if guild else None
    queue = bot.queues[guild_id]

    if not voice_client or not voice_client.is_connected():
        bot.current_track.pop(guild_id, None)
        await update_presence_for_guild(guild_id, track=None)
        return
    if voice_client.is_playing() or voice_client.is_paused():
        return
    if not queue:
        if guild_id in bot.autoplay:
            channel = bot.channels.get(guild_id)
            if channel:
                asyncio.create_task(channel.send("📻 Queue finished • Finding similar song with **Autoplay**..."))
            try:
                autoplay_track = await fetch_autoplay_track(guild_id)
            except Exception as e:
                print(f"Autoplay fetch error: {e}")
                autoplay_track = None

            if autoplay_track:
                queue.append(autoplay_track)
                channel = bot.channels.get(guild_id)
                if channel:
                    asyncio.create_task(channel.send(f"📻 **Autoplay**: Queued **{autoplay_track.title}**"))
            else:
                if voice_client and voice_client.channel:
                    asyncio.create_task(set_vc_status(voice_client.channel.id, "♫ /play to listen to songs"))
                channel = bot.channels.get(guild_id)
                if channel:
                    asyncio.create_task(channel.send("📻 Autoplay finished or no more unique similar tracks found."))
                await update_presence_for_guild(guild_id, track=None)
                return
        else:
            if voice_client and voice_client.channel:
                asyncio.create_task(set_vc_status(voice_client.channel.id, "♫ /play to listen to songs"))
            await update_presence_for_guild(guild_id, track=None)
            return

    track = queue.popleft()

    def after_playback(error: Exception | None) -> None:
        if error:
            print(f"Playback error: {error}")
        bot.track_start_time[guild_id] = 0.0
        bot.pause_start_time[guild_id] = 0.0
        bot.total_paused_duration[guild_id] = 0.0
        bot.loop.call_soon_threadsafe(lambda: asyncio.create_task(play_next(guild_id)))

    try:
        before_options = (
            "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5" if track.is_url else None
        )
        filter_str = bot.filters.get(guild_id, "")
        extra_options = f"-vn {filter_str}".strip()
        audio = discord.FFmpegPCMAudio(
            track.source,
            before_options=before_options,
            options=extra_options
        )
        vol = bot.volume.get(guild_id, 1.0)
        source = discord.PCMVolumeTransformer(audio, volume=vol)
        voice_client.play(source, after=after_playback)
        print(f"Now playing: {track.title}")

        bot.track_start_time[guild_id] = time.time()
        bot.pause_start_time[guild_id] = 0.0
        bot.total_paused_duration[guild_id] = 0.0
        bot.current_track[guild_id] = track
        bot.history[guild_id].insert(0, track)
        if len(bot.history[guild_id]) > 50:
            bot.history[guild_id].pop()

        # If Autoplay is ON and queue has <= 2 songs, refill more similar songs in advance
        if guild_id in bot.autoplay and len(bot.queues[guild_id]) <= 2:
            asyncio.create_task(refill_autoplay_queue(guild_id))

        # Show song playing strictly in THIS server's voice channel (does not broadcast to other servers)
        if voice_client and voice_client.channel:
            asyncio.create_task(set_vc_status(voice_client.channel.id, f"🎶 {track.title[:90]}"))

        # Update bot presence ONLY if playing in the bot owner's server
        await update_presence_for_guild(guild_id, track=track)

        embed = create_now_playing_embed(track)
        view = MusicControls(guild_id=guild_id)
        if initial_interaction and not initial_interaction.is_expired():
            try:
                if initial_interaction.response.is_done():
                    await initial_interaction.followup.send(embed=embed, view=view)
                else:
                    await initial_interaction.response.send_message(embed=embed, view=view)
            except Exception as e:
                print(f"Failed to send to initial_interaction: {e}")
                channel = bot.channels.get(guild_id)
                if channel:
                    await channel.send(embed=embed, view=view)
        else:
            channel = bot.channels.get(guild_id)
            if channel:
                await channel.send(embed=embed, view=view)
    except Exception as error:
        print(f"Could not play {track.title}: {error}")
        await update_presence_for_guild(guild_id, track=None)
        if initial_interaction and not initial_interaction.is_expired():
            try:
                msg = f"❌ Could not play **{track.title}**: `{error}`"
                if initial_interaction.response.is_done():
                    await initial_interaction.followup.send(msg)
                else:
                    await initial_interaction.response.send_message(msg)
            except Exception:
                pass
        await play_next(guild_id)


@bot.tree.command(name="play", description="Play a song from YouTube, a URL, or local music")
@app_commands.guild_only()
@app_commands.describe(source="Song name, YouTube URL, or local file name")
async def play(interaction: discord.Interaction, source: str) -> None:
    member = interaction.user
    if not isinstance(member, discord.Member) or not member.voice or not member.voice.channel:
        await interaction.response.send_message("❌ Join a voice channel first.", ephemeral=True)
        return

    # Deafen check (like Rythm!)
    if member.voice.self_deaf or member.voice.deaf:
        await interaction.response.send_message(
            f"🔇 {member.mention} You're deafened while trying to use 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛, undeafen to hear the music!",
            ephemeral=True
        )
        return

    await interaction.response.defer()
    requester_name = member.mention

    local_matches = find_tracks(source)
    if len(local_matches) == 1:
        local_file = local_matches[0]
        track = Track(
            title=local_file.name,
            source=str(local_file),
            is_url=False,
            duration="Local file",
            uploader="Local Library",
            requester=requester_name,
        )
    elif len(local_matches) > 1:
        choices = "\n".join(f"- `{path.name}`" for path in local_matches[:10])
        await interaction.followup.send(
            f"More than one song matches in local music. Try a more specific title:\n{choices}",
            ephemeral=True,
        )
        return
    else:
        # Search YouTube or load direct YouTube URL
        try:
            track = await asyncio.to_thread(extract_youtube_track, source, requester_name)
        except Exception as error:
            print(f"Could not load audio: {error}")
            await interaction.followup.send(
                f"I couldn't find or play audio for **{source}**."
            )
            return

    voice_client = await ensure_voice_connected(interaction, member)
    if voice_client is None:
        return

    bot.channels[interaction.guild_id] = interaction.channel
    queue = bot.queues[interaction.guild_id]

    is_currently_playing = voice_client.is_playing() or voice_client.is_paused()

    if is_currently_playing:
        queue.append(track)
        position = len(queue)
        added_embed = create_track_added_embed(track, position)
        await interaction.followup.send(embed=added_embed)
    else:
        queue.append(track)
        await play_next(interaction.guild_id, initial_interaction=interaction)


@bot.tree.command(name="import", description="Import and play a video or MP3 audio file in voice")
@app_commands.guild_only()
@app_commands.describe(file="Please attach a file (MP3 audio or Video song)")
async def import_command(interaction: discord.Interaction, file: discord.Attachment) -> None:
    member = interaction.user
    if not isinstance(member, discord.Member) or not member.voice or not member.voice.channel:
        await interaction.response.send_message("❌ Join a voice channel first to import and play music.", ephemeral=True)
        return

    if member.voice.self_deaf or member.voice.deaf:
        await interaction.response.send_message(
            f"🔇 {member.mention} You're deafened while trying to use 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛, undeafen to hear the music!",
            ephemeral=True
        )
        return

    filename = file.filename
    ext = Path(filename).suffix.lower()
    allowed_exts = {
        # Audio formats
        ".mp3", ".wav", ".m4a", ".flac", ".ogg", ".aac", ".opus", ".wma",
        # Video formats
        ".mp4", ".webm", ".mkv", ".mov", ".avi", ".flv"
    }

    if ext not in allowed_exts:
        await interaction.response.send_message(
            f"❌ Unsupported format `{ext}`. Please upload an MP3 audio (`.mp3`, `.wav`, `.m4a`, `.flac`) or Video song (`.mp4`, `.webm`, `.mov`, `.mkv`).",
            ephemeral=True
        )
        return

    await interaction.response.defer()

    imports_dir = BASE_DIR / "music" / "imports"
    imports_dir.mkdir(parents=True, exist_ok=True)

    clean_stem = re.sub(r'[^\w\s\-\.\(\)]', '', Path(filename).stem).strip() or "Imported_Track"
    dest_path = imports_dir / f"{clean_stem}_{int(time.time())}{ext}"

    try:
        await file.save(dest_path)
    except Exception as e:
        print(f"Error saving imported file: {e}")
        await interaction.followup.send(f"❌ Failed to download attachment: `{e}`")
        return

    dur_str, _ = get_media_duration_str(dest_path)
    is_video = ext in {".mp4", ".webm", ".mkv", ".mov", ".avi", ".flv"}
    track_type = "🎬 Video Audio" if is_video else "🎵 MP3 Audio"
    default_thumb = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80" if is_video else "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&auto=format&fit=crop&q=80"

    track = Track(
        title=clean_stem,
        source=str(dest_path),
        is_url=False,
        duration=dur_str,
        thumbnail=default_thumb,
        webpage_url=file.url,
        uploader=f"Imported ({track_type})",
        requester=member.mention
    )

    voice_client = await ensure_voice_connected(interaction, member)
    if voice_client is None:
        return

    bot.channels[interaction.guild_id] = interaction.channel
    queue = bot.queues[interaction.guild_id]

    is_currently_playing = voice_client.is_playing() or voice_client.is_paused()

    if is_currently_playing:
        queue.append(track)
        position = len(queue)
        added_embed = create_track_added_embed(track, position)
        added_embed.set_author(name=f"📂 {track_type} Imported & Queued", icon_url=bot.user.display_avatar.url if bot.user else None)
        await interaction.followup.send(embed=added_embed)
    else:
        queue.append(track)
        await play_next(interaction.guild_id, initial_interaction=interaction)


@bot.tree.command(name="files", description="List audio files available to play")
@app_commands.guild_only()
async def files(interaction: discord.Interaction) -> None:
    available = sorted(
        path.name for path in MUSIC_DIR.iterdir()
        if path.is_file() and path.suffix.lower() in SUPPORTED_FORMATS
    )
    if not available:
        message = "No supported audio files found in the `music` folder."
    else:
        message = "Available files:\n" + "\n".join(f"- `{name}`" for name in available[:50])
    await interaction.response.send_message(message, ephemeral=True)


@bot.tree.command(name="pause", description="Pause the current track")
@app_commands.guild_only()
async def pause(interaction: discord.Interaction) -> None:
    voice_client = interaction.guild.voice_client
    if voice_client and voice_client.is_playing():
        voice_client.pause()
        bot.pause_start_time[interaction.guild_id] = time.time()
        message = "Playback paused."
    else:
        message = "Nothing is playing."
    await interaction.response.send_message(message, ephemeral=True)


@bot.tree.command(name="resume", description="Resume the current track")
@app_commands.guild_only()
async def resume(interaction: discord.Interaction) -> None:
    voice_client = interaction.guild.voice_client
    if voice_client and voice_client.is_paused():
        voice_client.resume()
        if bot.pause_start_time.get(interaction.guild_id, 0) > 0:
            bot.total_paused_duration[interaction.guild_id] += time.time() - bot.pause_start_time[interaction.guild_id]
            bot.pause_start_time[interaction.guild_id] = 0.0
        message = "Playback resumed."
    else:
        message = "Playback isn't paused."
    await interaction.response.send_message(message, ephemeral=True)


@bot.tree.command(name="skip", description="Skip the current track")
@app_commands.guild_only()
async def skip(interaction: discord.Interaction) -> None:
    voice_client = interaction.guild.voice_client
    if voice_client:
        if voice_client.channel:
            asyncio.create_task(set_vc_status(voice_client.channel.id, "♫ /play to listen to songs"))
        if voice_client.is_playing() or voice_client.is_paused():
            voice_client.stop()
        message = "Skipped the current track."
    else:
        message = "Nothing is playing."
    await interaction.response.send_message(message, ephemeral=True)


@bot.tree.command(name="stop", description="Stop playback and clear the queue")
@app_commands.guild_only()
async def stop(interaction: discord.Interaction) -> None:
    bot.queues[interaction.guild_id].clear()
    bot.current_track.pop(interaction.guild_id, None)
    bot.track_start_time[interaction.guild_id] = 0.0
    bot.pause_start_time[interaction.guild_id] = 0.0
    bot.total_paused_duration[interaction.guild_id] = 0.0
    voice_client = interaction.guild.voice_client
    if voice_client:
        if voice_client.channel:
            asyncio.create_task(set_vc_status(voice_client.channel.id, "♫ /play to listen to songs"))
        if voice_client.is_playing() or voice_client.is_paused():
            voice_client.stop()
    asyncio.create_task(update_presence_for_guild(interaction.guild_id, track=None))
    await interaction.response.send_message("Playback stopped and queue cleared.", ephemeral=True)


@bot.tree.command(name="queue", description="Show the upcoming tracks")
@app_commands.guild_only()
async def show_queue(interaction: discord.Interaction) -> None:
    queue = list(bot.queues[interaction.guild_id])
    if not queue:
        message = "The queue is empty."
    else:
        message = "Up next:\n" + "\n".join(
            f"{index}. `{track.title}`" for index, track in enumerate(queue[:20], start=1)
        )
    await interaction.response.send_message(message, ephemeral=True)


class ProfileModal(discord.ui.Modal, title="Update Server Profile"):
    nick = discord.ui.TextInput(
        label="Bot Nickname",
        placeholder="Enter nickname for this server (or leave blank)...",
        required=False,
        max_length=32
    )
    avatar_url = discord.ui.TextInput(
        label="Avatar Image URL",
        placeholder="https://... direct image link (PNG/JPG/GIF)",
        required=False
    )
    banner_url = discord.ui.TextInput(
        label="Banner Image URL",
        placeholder="https://... direct image link (PNG/JPG/GIF)",
        required=False
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        app_info = await bot.application_info()
        if interaction.user.id != app_info.owner.id:
            await interaction.followup.send("❌ Only the bot owner can change the bot's avatar and banner. Contact bot owner: **@lanadelray_81**", ephemeral=True)
            return

        updated = []

        async with aiohttp.ClientSession() as session:
            if self.avatar_url.value.strip():
                try:
                    async with session.get(self.avatar_url.value.strip()) as resp:
                        if resp.status == 200:
                            data = await resp.read()
                            await bot.user.edit(avatar=data)
                            updated.append("Avatar")
                except Exception as e:
                    print(f"Avatar error: {e}")

            if self.banner_url.value.strip():
                try:
                    async with session.get(self.banner_url.value.strip()) as resp:
                        if resp.status == 200:
                            data = await resp.read()
                            await bot.user.edit(banner=data)
                            updated.append("Banner")
                except Exception as e:
                    print(f"Banner error: {e}")

        if self.nick.value.strip() and interaction.guild:
            try:
                await interaction.guild.me.edit(nick=self.nick.value.strip())
                updated.append("Nickname")
            except Exception as e:
                print(f"Nickname error: {e}")

        # Top confirmation card & aesthetic card (matches user screenshot 5!)
        notif = discord.Embed(
            title="見 Server Avatar",
            description=f"Ξ {interaction.user.mention} updated bot's server avatar for **{interaction.guild.name}**",
            color=discord.Color.from_rgb(26, 27, 30)
        )
        card = discord.Embed(
            title=f"三 ✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢ | {interaction.guild.name}",
            description="✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢",
            color=discord.Color.from_rgb(20, 21, 24)
        )
        try:
            u_obj = await bot.fetch_user(bot.user.id)
        except Exception:
            u_obj = bot.user
        if u_obj.display_avatar:
            card.set_thumbnail(url=u_obj.display_avatar.url)
        if u_obj.banner:
            card.set_image(url=u_obj.banner.url)

        await interaction.channel.send(embeds=[notif, card], view=CustomProfileView())
        await interaction.followup.send(f"✅ Updated: {', '.join(updated) if updated else 'No changes'}", ephemeral=True)


class CustomProfileView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Update Profile", style=discord.ButtonStyle.primary)
    async def update_profile(self, interaction: discord.Interaction, button: discord.ui.Button):
        app_info = await bot.application_info()
        if interaction.user.id != app_info.owner.id:
            await interaction.response.send_message("❌ Only the bot owner can update the bot's avatar and banner. Contact bot owner: **@lanadelray_81**", ephemeral=True)
            return
        await interaction.response.send_modal(ProfileModal())

    @discord.ui.button(label="Close", style=discord.ButtonStyle.secondary)
    async def close_panel(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            await interaction.message.delete()
        except Exception:
            await interaction.response.send_message("Closed.", ephemeral=True)


@bot.tree.command(name="customprofile", description="Open the interactive server profile & avatar manager")
@app_commands.guild_only()
async def custom_profile(interaction: discord.Interaction) -> None:
    app_info = await bot.application_info()
    if interaction.user.id != app_info.owner.id:
        await interaction.response.send_message("❌ Only the bot owner can access the profile manager. Contact bot owner: **@lanadelray_81**", ephemeral=True)
        return

    try:
        user_obj = await bot.fetch_user(bot.user.id)
    except Exception:
        user_obj = bot.user

    notif = discord.Embed(
        title="見 Server Avatar",
        description=f"Ξ {interaction.user.mention} updated bot's server avatar for **{interaction.guild.name}**",
        color=discord.Color.from_rgb(26, 27, 30)
    )
    card = discord.Embed(
        title=f"三 ✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢ | {interaction.guild.name}",
        description="✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢",
        color=discord.Color.from_rgb(20, 21, 24)
    )
    if user_obj.display_avatar:
        card.set_thumbnail(url=user_obj.display_avatar.url)
    if user_obj.banner:
        card.set_image(url=user_obj.banner.url)

    view = CustomProfileView()
    await interaction.response.send_message(embeds=[notif, card], view=view)


@bot.tree.command(name="setavatar", description="Set or update the bot's profile avatar (Bot Owner Only)")
@app_commands.guild_only()
@app_commands.describe(image="Upload image for the bot's avatar")
async def set_avatar(interaction: discord.Interaction, image: discord.Attachment) -> None:
    app_info = await bot.application_info()
    if interaction.user.id != app_info.owner.id:
        await interaction.response.send_message("❌ Only the bot owner can change the bot's avatar. Contact bot owner: **@lanadelray_81**", ephemeral=True)
        return

    if not image.content_type or not image.content_type.startswith("image/"):
        await interaction.response.send_message("❌ Please upload a valid image file.", ephemeral=True)
        return

    await interaction.response.defer()
    try:
        img_bytes = await image.read()
        await bot.user.edit(avatar=img_bytes)

        try:
            user_obj = await bot.fetch_user(bot.user.id)
        except Exception:
            user_obj = bot.user

        notif = discord.Embed(
            title="見 Bot Avatar Updated",
            description=f"Ξ {interaction.user.mention} updated bot's avatar for **{interaction.guild.name}**",
            color=discord.Color.from_rgb(26, 27, 30)
        )
        card = discord.Embed(
            title=f"三 ✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢ | {interaction.guild.name}",
            description="✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢",
            color=discord.Color.from_rgb(20, 21, 24)
        )
        if user_obj.display_avatar:
            card.set_thumbnail(url=user_obj.display_avatar.url)
        if user_obj.banner:
            card.set_image(url=user_obj.banner.url)

        await interaction.followup.send(embeds=[notif, card], view=CustomProfileView())
    except discord.HTTPException as e:
        await interaction.followup.send(f"⚠️ Discord limit/error: `{e}` (Discord limits avatar changes to twice per hour).")


@bot.tree.command(name="setbanner", description="Set or update the bot's profile banner (Bot Owner Only)")
@app_commands.guild_only()
@app_commands.describe(image="Upload image for the bot's banner")
async def set_banner(interaction: discord.Interaction, image: discord.Attachment) -> None:
    app_info = await bot.application_info()
    if interaction.user.id != app_info.owner.id:
        await interaction.response.send_message("❌ Only the bot owner can change the bot's banner. Contact bot owner: **@lanadelray_81**", ephemeral=True)
        return

    if not image.content_type or not image.content_type.startswith("image/"):
        await interaction.response.send_message("❌ Please upload a valid image file.", ephemeral=True)
        return

    await interaction.response.defer()
    try:
        img_bytes = await image.read()
        await bot.user.edit(banner=img_bytes)

        try:
            user_obj = await bot.fetch_user(bot.user.id)
        except Exception:
            user_obj = bot.user

        notif = discord.Embed(
            title="見 Bot Banner Updated",
            description=f"Ξ {interaction.user.mention} updated bot's banner for **{interaction.guild.name}**",
            color=discord.Color.from_rgb(26, 27, 30)
        )
        card = discord.Embed(
            title=f"三 ✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢ | {interaction.guild.name}",
            description="✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢",
            color=discord.Color.from_rgb(20, 21, 24)
        )
        if user_obj.display_avatar:
            card.set_thumbnail(url=user_obj.display_avatar.url)
        if user_obj.banner:
            card.set_image(url=user_obj.banner.url)

        await interaction.followup.send(embeds=[notif, card], view=CustomProfileView())
    except discord.HTTPException as e:
        await interaction.followup.send(f"⚠️ Discord limit/error: `{e}`")


# --- /security Group Commands (/security enable, /security disable, /security status) ---
security_group = app_commands.Group(name="security", description="Server security and defense controls")

@security_group.command(name="enable", description="Enable server security")
async def security_enable(interaction: discord.Interaction) -> None:
    app_info = await bot.application_info()
    if interaction.user.id != app_info.owner.id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ Administrator permission required. Contact bot owner: **@lanadelray_81**", ephemeral=True)
        return
    embed = discord.Embed(
        title="✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢",
        description=(
            "🛡️ **Server Security Enabled**\n\n"
            "> **❯ Anti-Nuke Protocol** : `[ ACTIVE ]`\n"
            "> **❯ Raid Limiter** : `[ ACTIVE ]`\n"
            "> **❯ Verification Gate** : `[ PROTECTED ]`\n"
            "> **❯ Guard Status** : `[ ONLINE ]`\n\n"
            f"Configured for **{interaction.guild.name}** by {interaction.user.mention}."
        ),
        color=discord.Color.from_rgb(20, 21, 24)
    )
    embed.set_thumbnail(url=LANA_LMR_URL)
    embed.set_footer(text="Blue Seal! -- Security Management.")
    await interaction.response.send_message(embed=embed)

@security_group.command(name="disable", description="Disable server security")
async def security_disable(interaction: discord.Interaction) -> None:
    app_info = await bot.application_info()
    if interaction.user.id != app_info.owner.id and not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ Administrator permission required. Contact bot owner: **@lanadelray_81**", ephemeral=True)
        return
    embed = discord.Embed(
        title="✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢",
        description=(
            "⚠️ **Server Security Disabled**\n\n"
            "> **❯ Anti-Nuke Protocol** : `[ DISABLED ]`\n"
            "> **❯ Raid Limiter** : `[ DISABLED ]`\n"
            "> **❯ Guard Status** : `[ STANDBY ]`"
        ),
        color=discord.Color.from_rgb(40, 20, 20)
    )
    embed.set_footer(text="Blue Seal! -- Security Management.")
    await interaction.response.send_message(embed=embed)

@security_group.command(name="status", description="Check current security configuration")
async def security_status(interaction: discord.Interaction) -> None:
    embed = discord.Embed(
        title="✢ | 𝐙𝐄𝐗𝐈 𝐎𝐍 𝐓𝐎𝐏 我 | ✢",
        description=(
            "🛡️ **Server Security Status**\n\n"
            "> **❯ Anti-Nuke Protocol** : `[ ACTIVE ]`\n"
            "> **❯ Anti-Spam Shield** : `[ ACTIVE ]`\n"
            "> **❯ Role Protection** : `[ SECURED ]`\n"
            "> **❯ Websocket Heartbeat** : `[ OPTIMAL ]`"
        ),
        color=discord.Color.from_rgb(20, 21, 24)
    )
    embed.set_thumbnail(url=LANA_LMR_URL)
    embed.set_footer(text="Blue Seal! -- Security Management.")
    await interaction.response.send_message(embed=embed)

bot.tree.add_command(security_group)

@bot.tree.command(name="setnick", description="Change the bot's server nickname (Bot Owner Only)")
@app_commands.guild_only()
@app_commands.describe(nickname="New nickname for the bot in this server")
async def set_nick(interaction: discord.Interaction, nickname: str) -> None:
    app_info = await bot.application_info()
    if interaction.user.id != app_info.owner.id:
        await interaction.response.send_message("🔒 **Protected**: The bot's nickname is locked to **`𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛`**. Only the bot owner (**@lanadelray_81**) can manage this.", ephemeral=True)
        return

    try:
        await interaction.guild.me.edit(nick=nickname)
        await interaction.response.send_message(f"✅ Bot nickname changed to **{nickname}** in this server!")
    except Exception as e:
        await interaction.response.send_message(f"⚠️ Could not change nickname: `{e}`", ephemeral=True)


@bot.tree.command(name="autoplay", description="Toggle continuous autoplay of related songs")
@app_commands.guild_only()
@app_commands.describe(mode="Turn autoplay on or off")
@app_commands.choices(mode=[
    app_commands.Choice(name="ON (Keep playing similar songs)", value="on"),
    app_commands.Choice(name="OFF", value="off"),
])
async def autoplay_cmd(interaction: discord.Interaction, mode: app_commands.Choice[str]) -> None:
    guild_id = interaction.guild_id
    if mode.value == "on":
        bot.autoplay.add(guild_id)
        await interaction.response.send_message("📻 **Autoplay enabled**! 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 will continuously play all similar tracks without repeating.")
        if guild_id in bot.current_track:
            async def _prequeue():
                channel = bot.channels.get(guild_id)
                if channel:
                    await channel.send("📻 Finding 5 similar songs for **Autoplay Playlist**...")
                similar = await fetch_similar_tracks(guild_id, count=5, requester="Autoplay 📻")
                if similar:
                    for t in similar:
                        bot.queues[guild_id].append(t)
                    if channel:
                        embed = discord.Embed(
                            title="📻 Autoplay Playlist Added",
                            description="\n".join(f"`{i}.` **[{t.title}]({t.webpage_url or ''})** (`{t.duration}`)" for i, t in enumerate(similar, 1)),
                            color=discord.Color.from_rgb(46, 204, 113)
                        )
                        embed.set_footer(text=f"Queued {len(similar)} continuous similar songs • No repeats")
                        await channel.send(embed=embed)
            asyncio.create_task(_prequeue())
    else:
        bot.autoplay.discard(guild_id)
        await interaction.response.send_message("📻 **Autoplay disabled**.")


@bot.tree.command(name="shuffle", description="Randomly shuffle upcoming songs in the queue")
@app_commands.guild_only()
async def shuffle_cmd(interaction: discord.Interaction) -> None:
    import random
    queue = bot.queues[interaction.guild_id]
    if len(queue) < 2:
        await interaction.response.send_message("❌ Need at least 2 songs in the queue to shuffle.", ephemeral=True)
        return
    tracks_list = list(queue)
    random.shuffle(tracks_list)
    bot.queues[interaction.guild_id] = deque(tracks_list)
    await interaction.response.send_message(f"🔀 Shuffled **{len(tracks_list)}** songs in the queue!")


@bot.tree.command(name="favorite", description="Save or remove the currently playing song in your favorites")
@app_commands.guild_only()
async def favorite_cmd(interaction: discord.Interaction) -> None:
    track = bot.current_track.get(interaction.guild_id)
    if not track:
        await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
        return
    favs = bot.favorites[interaction.user.id]
    if any(f.title == track.title for f in favs):
        bot.favorites[interaction.user.id] = [f for f in favs if f.title != track.title]
        await interaction.response.send_message(f"💔 Removed **{track.title}** from your favorites.", ephemeral=True)
    else:
        favs.append(track)
        await interaction.response.send_message(f"💖 Added **{track.title}** to your favorites! Use `/favorites` to view them.", ephemeral=True)


@bot.tree.command(name="favorites", description="View your saved favorite songs")
@app_commands.guild_only()
async def favorites_list(interaction: discord.Interaction) -> None:
    user_favs = bot.favorites.get(interaction.user.id, [])
    if not user_favs:
        await interaction.response.send_message("💔 You don't have any saved favorites yet. Use the 🤍 button or `/favorite` to save songs!", ephemeral=True)
        return
    embed = discord.Embed(
        title=f"💖 {interaction.user.display_name}'s Favorites",
        description="\n".join(f"`{i}.` **[{t.title}]({t.webpage_url or ''})** (`{t.duration}`)" for i, t in enumerate(user_favs[:15], start=1)),
        color=discord.Color.from_rgb(255, 105, 180)
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="leave", description="Disconnect the bot from voice")
@app_commands.guild_only()
async def leave(interaction: discord.Interaction) -> None:
    bot.queues[interaction.guild_id].clear()
    bot.current_track.pop(interaction.guild_id, None)
    if interaction.guild_id in bot.mode_247:
        bot.mode_247.discard(interaction.guild_id)
        bot.mode_247_channels.pop(interaction.guild_id, None)
        bot.save_247_config()
    voice_client = interaction.guild.voice_client
    if voice_client:
        if voice_client.channel:
            asyncio.create_task(set_vc_status(voice_client.channel.id, "♫ /play to listen to songs"))
        await voice_client.disconnect()
        message = "Disconnected from voice (24/7 mode disabled)."
    else:
        message = "I'm not in a voice channel."
    asyncio.create_task(update_presence_for_guild(interaction.guild_id, track=None))
    await interaction.response.send_message(message, ephemeral=True)


@bot.tree.command(name="bassboost", description="Toggle heavy bassboost audio filter")
@app_commands.guild_only()
@app_commands.describe(state="Turn bassboost on or off")
@app_commands.choices(state=[
    app_commands.Choice(name="ON (Heavy Bass)", value="on"),
    app_commands.Choice(name="OFF (Normal)", value="off"),
])
async def bassboost(interaction: discord.Interaction, state: app_commands.Choice[str]) -> None:
    guild_id = interaction.guild_id
    if state.value == "on":
        bot.filters[guild_id] = FILTER_PRESETS["bassboost"]
        await interaction.response.send_message("🔊 **Bassboost enabled**! Will apply to current & next tracks.")
    else:
        bot.filters[guild_id] = ""
        await interaction.response.send_message("🔉 **Bassboost disabled**.")


@bot.tree.command(name="8d", description="Toggle 8D spatial audio filter")
@app_commands.guild_only()
@app_commands.describe(state="Turn 8D surround sound on or off")
@app_commands.choices(state=[
    app_commands.Choice(name="ON (8D Surround)", value="on"),
    app_commands.Choice(name="OFF (Stereo)", value="off"),
])
async def eight_d(interaction: discord.Interaction, state: app_commands.Choice[str]) -> None:
    guild_id = interaction.guild_id
    if state.value == "on":
        bot.filters[guild_id] = FILTER_PRESETS["8d"]
        await interaction.response.send_message("🎧 **8D Audio enabled**! Use headphones for the best experience.")
    else:
        bot.filters[guild_id] = ""
        await interaction.response.send_message("🎧 **8D Audio disabled**.")


@bot.tree.command(name="filter", description="Unified audio filter preset manager")
@app_commands.guild_only()
@app_commands.describe(preset="Select an audio effect preset")
@app_commands.choices(preset=[
    app_commands.Choice(name="None (Clear)", value="clear"),
    app_commands.Choice(name="Bassboost", value="bassboost"),
    app_commands.Choice(name="8D Audio", value="8d"),
    app_commands.Choice(name="Nightcore", value="nightcore"),
    app_commands.Choice(name="Vaporwave", value="vaporwave"),
    app_commands.Choice(name="Karaoke", value="karaoke"),
])
async def filter_cmd(interaction: discord.Interaction, preset: app_commands.Choice[str]) -> None:
    guild_id = interaction.guild_id
    val = FILTER_PRESETS.get(preset.value, "")
    bot.filters[guild_id] = val
    if val:
        await interaction.response.send_message(f"🎛️ Applied audio filter: **{preset.name}**")
    else:
        await interaction.response.send_message("🎛️ Audio filters **cleared**.")


@bot.tree.command(name="247", description="Toggle 24/7 voice channel mode (auto-joins and stays connected)")
@app_commands.guild_only()
async def toggle_247(interaction: discord.Interaction) -> None:
    guild = interaction.guild
    guild_id = interaction.guild_id
    member = interaction.user

    if guild_id in bot.mode_247:
        bot.mode_247.discard(guild_id)
        bot.mode_247_channels.pop(guild_id, None)
        bot.save_247_config()
        await interaction.response.send_message("🔴 **24/7 Mode disabled**. 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 will disconnect when playback stops.")
    else:
        # Resolve target voice channel: user's voice channel or bot's current voice channel
        target_channel = None
        if isinstance(member, discord.Member) and member.voice and member.voice.channel:
            target_channel = member.voice.channel
        elif guild.voice_client and guild.voice_client.channel:
            target_channel = guild.voice_client.channel

        if not target_channel:
            await interaction.response.send_message("❌ Please join a voice channel first, then run `/247` so 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 knows which voice channel to stay in.", ephemeral=True)
            return

        await interaction.response.defer()

        # Connect or move to the voice channel immediately
        vc = guild.voice_client
        try:
            if not vc or not vc.is_connected():
                vc = await target_channel.connect(reconnect=True)
            elif vc.channel.id != target_channel.id:
                await vc.move_to(target_channel)
        except Exception as e:
            print(f"Error connecting to voice in {guild.name}: {e}")
            await interaction.followup.send(f"⚠️ Could not connect to voice channel: `{e}`", ephemeral=True)
            return

        bot.mode_247.add(guild_id)
        bot.mode_247_channels[guild_id] = target_channel.id
        bot.save_247_config()

        asyncio.create_task(set_vc_status(target_channel.id, "♫ /play to listen to songs"))

        await interaction.followup.send(
            f"🟢 **24/7 Mode enabled**! 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 joined **{target_channel.name}** and will stay connected 24/7 indefinitely (even after bot restarts)."
        )


@bot.tree.command(name="grab", description="Sends the currently playing song directly to your DMs")
@app_commands.guild_only()
async def grab(interaction: discord.Interaction) -> None:
    track = bot.current_track.get(interaction.guild_id)
    if not track:
        await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
        return

    embed = discord.Embed(
        title="📥 Saved Track",
        description=f"**[{track.title}]({track.webpage_url or 'https://youtube.com'})**",
        color=discord.Color.from_rgb(245, 197, 24)
    )
    if track.thumbnail:
        embed.set_thumbnail(url=track.thumbnail)
    embed.add_field(name="Duration", value=f"`{track.duration}`", inline=True)
    embed.add_field(name="Channel", value=f"`{track.uploader}`", inline=True)
    embed.add_field(name="Requested By", value=track.requester, inline=True)
    embed.set_footer(text=f"Saved from {interaction.guild.name} • 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛")

    try:
        await interaction.user.send(embed=embed)
        await interaction.response.send_message("📬 Sent to your DMs!", ephemeral=True)
    except discord.Forbidden:
        await interaction.response.send_message("❌ Cannot DM you. Please enable DMs from server members.", ephemeral=True)


@bot.tree.command(name="clear", description="Clear all tracks from the queue")
@app_commands.guild_only()
async def clear_queue(interaction: discord.Interaction) -> None:
    queue = bot.queues[interaction.guild_id]
    count = len(queue)
    queue.clear()
    await interaction.response.send_message(f"🗑️ Cleared **{count}** tracks from the queue.", ephemeral=True)


@bot.tree.command(name="history", description="View recently played tracks in this server")
@app_commands.guild_only()
async def history(interaction: discord.Interaction) -> None:
    hist = bot.history.get(interaction.guild_id, [])
    if not hist:
        await interaction.response.send_message("📜 No tracks played recently.", ephemeral=True)
        return

    embed = discord.Embed(
        title="📜 Playback History",
        description="\n".join(f"`{i}.` **[{t.title}]({t.webpage_url or ''})** (`{t.duration}`)" for i, t in enumerate(hist[:10], start=1)),
        color=discord.Color.from_rgb(32, 34, 37)
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="join", description="Connect the bot to your voice channel")
@app_commands.guild_only()
async def join_channel(interaction: discord.Interaction) -> None:
    member = interaction.user
    if not isinstance(member, discord.Member) or not member.voice or not member.voice.channel:
        await interaction.response.send_message("❌ Join a voice channel first.", ephemeral=True)
        return
    channel = member.voice.channel
    vc = interaction.guild.voice_client
    if vc is None or not vc.is_connected():
        if vc is not None:
            try:
                await vc.disconnect(force=True)
            except Exception:
                pass
        try:
            await channel.connect(reconnect=True)
            if interaction.guild_id in bot.mode_247:
                bot.mode_247_channels[interaction.guild_id] = channel.id
                bot.save_247_config()
            await interaction.response.send_message(f"🔊 Joined **{channel.name}**!")
        except Exception as e:
            await interaction.response.send_message(f"❌ Could not connect: `{e}`", ephemeral=True)
    elif vc.channel != channel:
        bot.authorized_vc_moves[interaction.guild_id] = time.time() + 5.0
        if interaction.guild_id in bot.mode_247:
            bot.mode_247_channels[interaction.guild_id] = channel.id
            bot.save_247_config()
        await vc.move_to(channel)
        await interaction.response.send_message(f"🔊 Moved to **{channel.name}**!")
    else:
        await interaction.response.send_message(f"🔊 Already connected to **{channel.name}**.", ephemeral=True)


LANA_LMR_URL = "https://i.pinimg.com/736x/8f/c9/2e/8fc92ee718b53d5a1bc0cfbe62b5a5ba.jpg"


def format_uptime(boot_time: float) -> str:
    total_sec = max(0, int(time.time() - boot_time))
    days, rem = divmod(total_sec, 86400)
    hours, rem = divmod(rem, 3600)
    mins, secs = divmod(rem, 60)
    return f"{days}d {hours}h {mins}m {secs}s"


@bot.tree.command(name="ping", description="Check the bot's latency and system status")
@app_commands.guild_only()
async def ping(interaction: discord.Interaction) -> None:
    heartbeat = safe_latency(bot.latency)
    if heartbeat <= 100:
        dot = "🟢"
    elif heartbeat <= 200:
        dot = "🟡"
    else:
        dot = "🔴"

    uptime_str = format_uptime(bot.boot_time)
    servers = len(bot.guilds)
    total_members = sum(g.member_count or 0 for g in bot.guilds)

    embed = discord.Embed(
        title="📣 Bot Latency & System Status",
        description=(
            f"» WebSocket Latency: **{heartbeat}ms** {dot}\n"
            f"» Bot Uptime: **{uptime_str}**\n"
            f"» Active Servers: **{servers}**\n"
            f"» Total Members: **{total_members:,}**\n\n"
            f"**developed by 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛**"
        ),
        color=discord.Color.from_rgb(18, 19, 22)
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="addsimilarsongs", description="Adds 3 similar songs to your queue based on the current track")
@app_commands.guild_only()
async def add_similar_songs(interaction: discord.Interaction) -> None:
    guild_id = interaction.guild_id
    current = bot.current_track.get(guild_id)
    if not current:
        await interaction.response.send_message("❌ Nothing is currently playing to find similar songs for.", ephemeral=True)
        return

    await interaction.response.defer()
    try:
        similar = await fetch_similar_tracks(guild_id, count=3, requester=interaction.user.mention)
        if similar:
            for t in similar:
                bot.queues[guild_id].append(t)
            embed = discord.Embed(
                title="🎶 Added Similar Songs",
                description="\n".join(f"`{i}.` **[{t.title}]({t.webpage_url or ''})** (`{t.duration}`)" for i, t in enumerate(similar, start=1)),
                color=discord.Color.from_rgb(245, 197, 24)
            )
            embed.set_footer(text=f"Based on: {current.title[:45]} • 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛")
            await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send("❌ Could not find new unique similar songs.")
    except Exception as e:
        await interaction.followup.send(f"⚠️ Error finding similar songs: `{e}`")


@bot.tree.command(name="lyrics", description="Display lyrics or details for the current song")
@app_commands.guild_only()
async def lyrics_cmd(interaction: discord.Interaction) -> None:
    current = bot.current_track.get(interaction.guild_id)
    if not current:
        await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
        return
    embed = discord.Embed(
        title=f"📜 Song Details • {current.title[:45]}",
        description=f"**Title**: [{current.title}]({current.webpage_url or 'https://youtube.com'})\n**Channel/Artist**: `{current.uploader}`\n**Duration**: `{current.duration}`\n**Requested by**: {current.requester}\n\n*Live streaming synced with web dashboard!*",
        color=discord.Color.from_rgb(245, 197, 24)
    )
    if current.thumbnail:
        embed.set_thumbnail(url=current.thumbnail)
    embed.set_footer(text=f"Requested by {current.requester} • 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="about", description="View information, stats, and links for 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛")
async def about(interaction: discord.Interaction) -> None:
    guild_count = len(bot.guilds)
    user_count = sum(g.member_count or 0 for g in bot.guilds)
    ping = safe_latency(bot.latency)

    embed = discord.Embed(
        title="⚡ About 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛",
        description="High-fidelity Discord music bot with 24-bit audio, interactive buttons, and real-time audio filters.",
        color=discord.Color.from_rgb(245, 197, 24)
    )
    embed.add_field(name="📶 Latency", value=f"`{ping}ms`", inline=True)
    embed.add_field(name="🌐 Servers", value=f"`{guild_count}`", inline=True)
    embed.add_field(name="👥 Users", value=f"`{user_count}`", inline=True)
    embed.add_field(name="👑 Bot Owner", value="`@lanadelray_81`", inline=True)
    embed.add_field(name="🐍 Python", value=f"`discord.py {discord.__version__}`", inline=True)
    embed.add_field(name="🎵 Engine", value="`yt-dlp + FFmpeg`", inline=True)
    embed.add_field(name="🔗 Invite", value="[Invite LANA DEL REY 愛](https://discord.com/oauth2/authorize?client_id=1566582982167232634&permissions=554154970560&scope=bot%20applications.commands)", inline=True)
    embed.set_footer(text="developed by 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛 • Owner: @lanadelray_81")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="invite", description="Get the official bot invite link")
async def invite(interaction: discord.Interaction) -> None:
    embed = discord.Embed(
        title="✨ Invite LANA DEL REY 愛 to Your Server",
        description="Add the bot to stream crystal-clear audio with YouTube search, filters, and button controls!",
        color=discord.Color.from_rgb(245, 197, 24)
    )
    view = discord.ui.View()
    invite_url = "https://discord.com/oauth2/authorize?client_id=1566582982167232634&permissions=554154970560&scope=bot%20applications.commands"
    view.add_item(discord.ui.Button(label="Add to Discord", url=invite_url, emoji="✨"))
    await interaction.response.send_message(embed=embed, view=view)


@bot.tree.command(name="help", description="Displays the full bot command menu")
async def help_command(interaction: discord.Interaction) -> None:
    embed = discord.Embed(
        title="⚡ LANA DEL REY 愛 Command Menu",
        description="Here are all available slash commands:",
        color=discord.Color.from_rgb(245, 197, 24)
    )
    embed.add_field(
        name="🎶 Music Commands",
        value=(
            "`/play <query>` - Play song name or YouTube link\n"
            "`/import <file>` - Import and play a video or MP3 audio file\n"
            "`/pause` & `/resume` - Pause or resume playback\n"
            "`/skip` - Skip current track\n"
            "`/stop` - Stop audio & clear queue\n"
            "`/queue` - Show upcoming tracks\n"
            "`/clear` - Clear all queued tracks\n"
            "`/join` - Join your voice channel"
        ),
        inline=False
    )
    embed.add_field(
        name="🎛️ Audio Filters",
        value=(
            "`/bassboost` - Toggle heavy bass audio filter\n"
            "`/8d` - Toggle 8D surround sound audio filter\n"
            "`/filter` - Choose Nightcore, Vaporwave, 8D, or Clear"
        ),
        inline=False
    )
    embed.add_field(
        name="🎨 Customization & Profile",
        value=(
            "`/setavatar <image>` - Change bot profile picture\n"
            "`/setbanner <image>` - Change bot profile banner\n"
            "`/setnick <name>` - Change bot server nickname"
        ),
        inline=False
    )
    embed.add_field(
        name="⚙️ Utilities & Info",
        value=(
            "`/ping` - Check latency and websocket status\n"
            "`/247` - Keep bot in voice channel 24/7\n"
            "`/grab` - Send currently playing track to your DMs\n"
            "`/history` - View recently played tracks\n"
            "`/about` - Bot stats, ping, and server count\n"
            "`/contact <msg>` - Send message to bot owner\n"
            "`/invite` - Get bot invite link\n"
            "`/owner` - Owner verification info"
        ),
        inline=False
    )
    embed.set_footer(text="Bot Owner: @lanadelray_81 • Use /contact to send feedback!")
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="owner", description="Check bot owner stats and admin info")
async def owner_command(interaction: discord.Interaction) -> None:
    app_info = await bot.application_info()
    if interaction.user.id == app_info.owner.id:
        guild_count = len(bot.guilds)
        queue_count = sum(len(q) for q in bot.queues.values())
        total_members = sum(g.member_count or 0 for g in bot.guilds)
        await interaction.response.send_message(
            f"👑 **Owner Verified**: Welcome, {interaction.user.mention}!\n"
            f"🤖 **Bot ID**: `{bot.user.id}`\n"
            f"🆔 **Your Owner ID**: `{interaction.user.id}`\n"
            f"🌐 **Active Servers**: `{guild_count}`\n"
            f"👥 **Total Members**: `{total_members}`\n"
            f"🎶 **Queued Tracks**: `{queue_count}`",
            ephemeral=True
        )
    else:
        await interaction.response.send_message("❌ This command is only for the bot owner. Contact bot owner: **@lanadelray_81**", ephemeral=True)


@bot.tree.command(name="contact", description="Send a direct message or feedback to the bot owner")
@app_commands.describe(message="The message or question you want to send to @lanadelray_81")
async def contact_owner(interaction: discord.Interaction, message: str) -> None:
    app_info = await bot.application_info()
    owner = app_info.owner

    embed = discord.Embed(
        title="📬 New Message from User",
        description=message,
        color=discord.Color.from_rgb(245, 197, 24)
    )
    embed.add_field(name="Sender", value=f"{interaction.user.mention} (`{interaction.user}`)", inline=True)
    embed.add_field(name="Server", value=f"**{interaction.guild.name if interaction.guild else 'Direct Messages'}**", inline=True)
    embed.set_footer(text=f"User ID: {interaction.user.id}")

    try:
        await owner.send(embed=embed)
        await interaction.response.send_message(f"✅ Your message has been sent to the bot owner (**@lanadelray_81**)!", ephemeral=True)
    except Exception:
        await interaction.response.send_message(f"📬 You can contact the bot owner directly: **@lanadelray_81**", ephemeral=True)



@bot.tree.command(name="controller", description="Display the complete music playback & extras control panel")
@app_commands.guild_only()
async def controller_cmd(interaction: discord.Interaction) -> None:
    guild_id = interaction.guild_id
    if not guild_id:
        await interaction.response.send_message("Please use this command in a server.", ephemeral=True)
        return
    playback_view = PlaybackControls(guild_id)
    extras_view = ExtrasControls(guild_id)
    await interaction.response.send_message(
        content="**Playback**",
        view=playback_view
    )
    await interaction.followup.send(
        content="**Extras**",
        view=extras_view
    )


@bot.tree.command(name="stream", description="Stream YouTube video song in 720P 30FPS & launch Watch Together")
@app_commands.guild_only()
@app_commands.describe(query="Song title, video name, or YouTube URL to stream (e.g. 'hindi item songs')")
async def stream_command(interaction: discord.Interaction, query: str = None) -> None:
    await perform_stream(interaction, query)


@bot.event
async def on_ready() -> None:
    app_info = await bot.application_info()
    bot.owner_id = app_info.owner.id
    print(f"Ready as {bot.user}")
    print(f"Bot Owner: {app_info.owner} (ID: {app_info.owner.id})")

    # Clear duplicate guild-specific commands so commands only appear ONCE under LANA DEL REY 愛
    for g in bot.guilds:
        try:
            bot.tree.clear_commands(guild=g)
            await bot.tree.sync(guild=g)
            print(f"Cleared duplicate guild commands from {g.name} ({g.id})", flush=True)
        except Exception as e:
            print(f"Could not clear guild commands for {g.name}: {e}", flush=True)

        try:
            if g.me and g.me.guild_permissions.change_nickname:
                await g.me.edit(nick="𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛")
        except Exception:
            pass

    try:
        await bot.tree.sync()
        print("Successfully synced clean global slash commands!", flush=True)
    except Exception as e:
        print(f"Global sync error: {e}", flush=True)

    activity = discord.Activity(
        type=discord.ActivityType.listening,
        name="/play | 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛"
    )
    await bot.change_presence(status=discord.Status.online, activity=activity)

    for g in bot.guilds:
        if g.owner_id == bot.owner_id:
            OWNER_GUILD_IDS.add(g.id)

    # Auto-reconnect to all saved 24/7 voice channels across restarts
    if bot.mode_247_channels:
        print(f"🔄 Auto-rejoining {len(bot.mode_247_channels)} saved 24/7 voice channels...")
        for g_id, c_id in list(bot.mode_247_channels.items()):
            g_obj = bot.get_guild(g_id)
            if not g_obj:
                continue
            c_obj = g_obj.get_channel(c_id)
            if not c_obj or not isinstance(c_obj, (discord.VoiceChannel, discord.StageChannel)):
                continue
            try:
                g_vc = g_obj.voice_client
                if not g_vc or not g_vc.is_connected():
                    await c_obj.connect(reconnect=True)
                    print(f"✅ Auto-joined 24/7 channel '{c_obj.name}' in '{g_obj.name}' on boot")
                elif g_vc.channel.id != c_id:
                    await g_vc.move_to(c_obj)
                asyncio.create_task(set_vc_status(c_obj.id, "♫ /play to listen to songs"))
            except Exception as e:
                print(f"Failed to auto-join 24/7 channel in {g_obj.name}: {e}")


@bot.event
async def on_voice_state_update(member: discord.Member, before: discord.VoiceState, after: discord.VoiceState) -> None:
    # Handle bot's own voice state changes
    if member.id == bot.user.id:
        guild_id = member.guild.id
        is_247 = guild_id in bot.mode_247_channels
        c_id = bot.mode_247_channels.get(guild_id)

        # CASE 1: Bot was disconnected from voice
        if after.channel is None:
            if before.channel:
                asyncio.create_task(set_vc_status(before.channel.id, "♫ /play to listen to songs"))

            if not is_247:
                # Normal mode: clean up queues and presence
                bot.queues[guild_id].clear()
                bot.current_track.pop(guild_id, None)
                bot.track_start_time[guild_id] = 0.0
                bot.pause_start_time[guild_id] = 0.0
                bot.total_paused_duration[guild_id] = 0.0
                asyncio.create_task(update_presence_for_guild(guild_id, track=None))
            else:
                # 24/7 Active Mode: A member disconnected the bot!
                # Instantly rejoin THAT designated voice channel ONLY and resume music!
                saved_track = bot.current_track.get(guild_id)

                async def _instant_rejoin_247():
                    # 0.8s allows Discord voice gateway to close previous session cleanly
                    await asyncio.sleep(0.8)
                    chan = member.guild.get_channel(c_id)
                    if chan and isinstance(chan, (discord.VoiceChannel, discord.StageChannel)):
                        try:
                            vc = member.guild.voice_client
                            if not vc or not vc.is_connected():
                                vc = await chan.connect(reconnect=True)
                                print(f"🔒 24/7 Shield: Member disconnected bot in '{member.guild.name}', automatically rejoined '{chan.name}'!")
                                await set_vc_status(chan.id, "♫ /play to listen to songs")
                            elif vc.channel.id != c_id:
                                await vc.move_to(chan)

                            # If music was playing before disconnect, resume it seamlessly
                            if saved_track and not (vc.is_playing() or vc.is_paused()):
                                bot.queues[guild_id].appendleft(saved_track)
                                asyncio.create_task(play_next(guild_id))
                        except Exception as err:
                            print(f"24/7 Auto-rejoin error in {member.guild.name}: {err}")

                asyncio.create_task(_instant_rejoin_247())

        # CASE 2: Bot was moved to another channel by a member
        elif after.channel is not None and is_247 and c_id and after.channel.id != c_id:
            # If move was triggered by an authorized command (/play, /join, web dashboard), adopt the new channel
            if bot.authorized_vc_moves.get(guild_id, 0) > time.time():
                bot.mode_247_channels[guild_id] = after.channel.id
                bot.save_247_config()
                return

            # Member moved/dragged the bot away from its 24/7 channel!
            # Automatically return to THAT voice channel only!
            target_chan = member.guild.get_channel(c_id)
            if target_chan and isinstance(target_chan, (discord.VoiceChannel, discord.StageChannel)):
                async def _revert_to_channel():
                    await asyncio.sleep(0.5)
                    try:
                        vc = member.guild.voice_client
                        if vc and vc.is_connected() and vc.channel.id != c_id:
                            await vc.move_to(target_chan)
                            print(f"🔒 24/7 Shield: Bot moved away from '{target_chan.name}' by member, automatically moved back!")
                    except Exception as err:
                        print(f"24/7 channel return error: {err}")
                asyncio.create_task(_revert_to_channel())


@bot.event
async def on_member_update(before: discord.Member, after: discord.Member) -> None:
    # Anti-Tamper Shield: Prevent any server manager/admin from renaming the bot
    if after.id == bot.user.id and before.nick != after.nick:
        LOCKED_NICKNAME = "𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛"
        if after.nick != LOCKED_NICKNAME:
            try:
                changer_is_owner = False
                app_info = await bot.application_info()
                if after.guild.me.guild_permissions.view_audit_log:
                    try:
                        async for entry in after.guild.audit_logs(action=discord.AuditLogAction.member_update, limit=3):
                            if entry.target and entry.target.id == bot.user.id:
                                if entry.user and entry.user.id == app_info.owner.id:
                                    changer_is_owner = True
                                break
                    except Exception:
                        pass

                if not changer_is_owner:
                    if after.guild.me.guild_permissions.change_nickname:
                        await after.guild.me.edit(nick=LOCKED_NICKNAME)
                        print(f"🔒 Anti-Tamper: Reverted unauthorized nickname change in '{after.guild.name}' back to '{LOCKED_NICKNAME}'")
            except Exception as e:
                print(f"Anti-Tamper warning: Could not revert nickname in {after.guild.name}: {e}")


@bot.event
async def on_guild_join(guild: discord.Guild) -> None:
    print(f"🎉 Joined new guild: {guild.name} ({guild.id})")

    # 1. Clear any guild command copies so the guild uses clean global commands without duplicates
    try:
        bot.tree.clear_commands(guild=guild)
        await bot.tree.sync(guild=guild)
        print(f"Cleared guild command duplicates for newly joined guild: {guild.name}")
    except Exception as e:
        print(f"Could not clear guild commands on join: {e}")

    # 2. Try to change nickname to 𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛
    try:
        if guild.me and guild.me.guild_permissions.change_nickname:
            await guild.me.edit(nick="𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘    愛")
    except Exception:
        pass

    # Wait for Discord audit logs and membership to settle
    await asyncio.sleep(1.5)

    # 3. Accurately resolve Server Owner (via cache or direct Discord REST API fetch)
    owner_user: discord.User | discord.Member | None = None
    if guild.owner:
        owner_user = guild.owner
    elif guild.owner_id:
        owner_user = bot.get_user(guild.owner_id)
        if not owner_user:
            try:
                owner_user = await bot.fetch_user(guild.owner_id)
            except Exception as e:
                print(f"Could not fetch server owner: {e}")

    if owner_user:
        server_owner_str = f"👤 **[@{owner_user.name}](https://discord.com/users/{owner_user.id})** (Display: **{owner_user.display_name}**)\n🆔 **ID:** `{owner_user.id}`"
    elif guild.owner_id:
        server_owner_str = f"🆔 **ID:** `{guild.owner_id}`"
    else:
        server_owner_str = "Unknown"

    # 4. Find out WHO added the bot
    added_by_user: discord.User | discord.Member | None = None
    added_by_str: str | None = None

    # Step 4A: Check Audit Logs if bot has View Audit Log permission
    try:
        if guild.me and guild.me.guild_permissions.view_audit_log:
            async for entry in guild.audit_logs(action=discord.AuditLogAction.bot_add, limit=10):
                if entry.target and entry.target.id == bot.user.id:
                    added_by_user = entry.user
                    break
            if not added_by_user:
                async for entry in guild.audit_logs(limit=10):
                    if entry.target and entry.target.id == bot.user.id:
                        added_by_user = entry.user
                        break
    except Exception as e:
        print(f"Audit log check error: {e}")

    if added_by_user:
        added_by_str = f"👤 **[@{added_by_user.name}](https://discord.com/users/{added_by_user.id})** (Display: **{added_by_user.display_name}**)\n🆔 **ID:** `{added_by_user.id}`"
    else:
        # Step 4B: Guaranteed Fallback - Server Owner is the creator/manager who authorized the bot
        if owner_user:
            if (guild.member_count or 0) <= 3:
                added_by_str = f"👑 **[@{owner_user.name}](https://discord.com/users/{owner_user.id})** (Server Owner)\n🆔 **ID:** `{owner_user.id}`"
            else:
                added_by_str = f"👑 **[@{owner_user.name}](https://discord.com/users/{owner_user.id})** (Server Owner / Manager)\n🆔 **ID:** `{owner_user.id}`"
        elif guild.owner_id:
            added_by_str = f"👑 **Server Owner**\n🆔 **ID:** `{guild.owner_id}`"
        else:
            added_by_str = "Server Administrator"

    # 5. Gather server stats
    total_servers = len(bot.guilds)
    total_members = sum(g.member_count or 0 for g in bot.guilds)

    # 5. Build rich notification embed for the bot owner
    embed = discord.Embed(
        title="🎉 Bot Added to a New Server!",
        description=f"**`𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛`** was just invited and added to **{guild.name}**!",
        color=discord.Color.from_rgb(46, 204, 113),
        timestamp=discord.utils.utcnow()
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)

    embed.add_field(name="🏰 Server Name", value=f"**{guild.name}**", inline=True)
    embed.add_field(name="🆔 Server ID", value=f"`{guild.id}`", inline=True)
    embed.add_field(name="👥 Server Members", value=f"`{guild.member_count or 'Unknown'}` members", inline=True)
    embed.add_field(name="👤 Added By", value=added_by_str, inline=False)
    embed.add_field(name="👑 Server Owner", value=server_owner_str, inline=False)
    embed.add_field(name="🌐 Total Servers Now", value=f"`{total_servers}` servers", inline=True)
    embed.add_field(name="📈 Total Reach", value=f"`{total_members}` total members", inline=True)

    bot_avatar = bot.user.display_avatar.url if bot.user else None
    embed.set_footer(text="LANA DEL REY 愛 • Server Tracker Alert", icon_url=bot_avatar)

    # 6. Send DM directly to Bot Owner
    try:
        app_info = await bot.application_info()
        owner = bot.get_user(app_info.owner.id) or await bot.fetch_user(app_info.owner.id)
        if owner:
            await owner.send(embed=embed)
            print(f"Sent server join alert DM to bot owner: {owner}")
    except Exception as err:
        print(f"Failed to send DM to bot owner: {err}")


@bot.event
async def on_guild_remove(guild: discord.Guild) -> None:
    print(f"⚠️ Removed from guild: {guild.name} ({guild.id})")
    total_servers = len(bot.guilds)
    total_members = sum(g.member_count or 0 for g in bot.guilds)

    embed = discord.Embed(
        title="⚠️ Bot Removed from a Server",
        description=f"**`𝐋𝐀𝐍𝐀 𝐃𝐄𝐋 𝐑𝐄𝐘 愛`** was removed/kicked from **{guild.name}**.",
        color=discord.Color.from_rgb(231, 76, 60),
        timestamp=discord.utils.utcnow()
    )
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)

    embed.add_field(name="🏰 Server Name", value=f"**{guild.name}**", inline=True)
    embed.add_field(name="🆔 Server ID", value=f"`{guild.id}`", inline=True)
    embed.add_field(name="👥 Members Lost", value=f"`{guild.member_count or 'Unknown'}` members", inline=True)
    embed.add_field(name="🌐 Remaining Servers", value=f"`{total_servers}` servers", inline=True)
    embed.add_field(name="📈 Remaining Total Members", value=f"`{total_members}` members", inline=True)
    embed.set_footer(text="LANA DEL REY 愛 • Server Tracker Alert")

    try:
        app_info = await bot.application_info()
        owner = bot.get_user(app_info.owner.id) or await bot.fetch_user(app_info.owner.id)
        if owner:
            await owner.send(embed=embed)
    except Exception as err:
        print(f"Failed to send removal DM to bot owner: {err}")


if __name__ == "__main__":
    MUSIC_DIR.mkdir(exist_ok=True)
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("Set DISCORD_TOKEN in your .env file before starting the bot.")
    bot.run(token)